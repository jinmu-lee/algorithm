//#include "Point1.h"
#include "Point2.h"

int main()
{
    Point p(1,2);
    p.Print();
}
