// Point1.h
class Point
{
    int x, y;
    int debug;
public:
    Point( int a = 0, int b = 0);

    void Print() const;
};
