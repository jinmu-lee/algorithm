// PointImpl.h
class PointImpl
{
    int x, y;
    int debug;
public:
    PointImpl( int a = 0, int b = 0);

    void Print() const;
};
