if(strcmp("/etc/issue", tmp->name)==0) {
	printk("Information of %s\n", tmp->name);
	printk("file size: %lld\n", f->f_path.dentry->d_inode->i_size);
	printk("filesystem type: %s\n", f->f_path.dentry->d_inode->i_sb->s_type->name);
}
