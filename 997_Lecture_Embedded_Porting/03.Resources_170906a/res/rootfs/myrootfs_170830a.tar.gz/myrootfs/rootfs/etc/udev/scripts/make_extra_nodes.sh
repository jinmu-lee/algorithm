#! /bin/bash
# Make extra /dev nodes.
#
# Copyright (C) 2004 Greg Kroah-Hartman <greg@kroah.com>
# Released under the GPL v2 only.
#
# Enhanced for Slackware Linux by volkerdi@slackware.com.

if [ -z $udev_root ]; then
  . /etc/udev/udev.conf
fi

# these are a few things that sysfs does not export for us.
ln -snf /proc/self/fd $udev_root/fd
ln -snf /proc/self/fd/0 $udev_root/stdin
ln -snf /proc/self/fd/1 $udev_root/stdout
ln -snf /proc/self/fd/2 $udev_root/stderr
ln -snf /proc/kcore $udev_root/core
if [ -r $udev_root/psaux ]; then
  ( cd $udev_root ; ln -sf psaux mouse )
fi
mkdir $udev_root/pts
mkdir $udev_root/shm

# We don't want to kludge *every* possible device, but a few would certainly be
# useful.  Most of the benefit in udev is the massive reduction of tty/pty clutter
# (well, IMO), and I'd like to see kmod remain functional.  I'd take a few more
# requests here.  :-)
if [ ! -r /dev/rtc ]; then
  mknod -m 664 /dev/rtc c 10 135
fi

