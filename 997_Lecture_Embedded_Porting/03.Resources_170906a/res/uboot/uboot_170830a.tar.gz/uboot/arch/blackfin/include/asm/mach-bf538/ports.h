/*
 * Port Masks
 */

#ifndef __BFIN_PERIPHERAL_PORT__
#define __BFIN_PERIPHERAL_PORT__

#include "../mach-common/bits/ports-c.h"
#include "../mach-common/bits/ports-d.h"
#include "../mach-common/bits/ports-e.h"
#include "../mach-common/bits/ports-f.h"

#endif
