
extern int run_directory(const char *dir, const char *suffix, const char *subsystem);

