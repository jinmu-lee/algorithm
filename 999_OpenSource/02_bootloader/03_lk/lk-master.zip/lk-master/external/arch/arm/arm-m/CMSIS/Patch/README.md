This directory contains patches made to ARM/CMSIS for LK compatibility reasons.
