#ifndef __LIB_LWIP_ARCH_PERF_H
#define __LIB_LWIP_ARCH_PERF_H

#define PERF_START do {} while (0)
#define PERF_STOP(x) do {} while (0)

#endif

