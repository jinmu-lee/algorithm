import tensorflow as tf
import numpy as np

x_data =np.random.randn(2000,3)
w_real = [0.3, 0.5, 1]
b_real = -0.2

y_data = np.matmul(x_data,w_real) + b_real
NUM_STEPS = 100
graph = tf.Graph()

with graph.as_default():
    with tf.name_scope("interface"):
        x = tf.placeholder(tf.)

    with tf.name_scope("loss_layer"):
        loss = -tf.reduce_mean(y_data * tf.log(y) + (1 - y_data) * tf.log(1 - y))

    with tf.name_scope("train"):
        learning_rate = 0.1
        gradient_decent = tf.train.GradientDescentOptimizer(learning_rate).minimize(loss)
        predicted = tf.cast(y > 0.5, dtype=tf.float64)
        accuracy = tf.reduce_mean(tf.cast(tf.equal(predicted, y_data), dtype=tf.float64))

with tf.Session(graph=graph) as sess:
    for i in range(101):
        w_,b_= sess.run([w_real,b_real])
        if (i+1) % 5 == 0:
            print('epoch : %.f weight : %.4f, bias=%.4f'%(i+1,w_,b_))

    sess.run(tf.global_variables_initializer())
    tf.summary.FileWriter('./my_graph', graph)