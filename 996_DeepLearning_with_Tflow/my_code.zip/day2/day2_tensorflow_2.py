
import tensorflow as tf

a = tf.constant([5,3],name='input_a')
b = tf.reduce_prod(a,name='prod_b')
c = tf.reduce_sum(a,name='sum_c')

d = tf.add(b,c,name='add_d')
with tf.Session() as sess:
    #result,r_a,r_b,r_c = sess.run([d,a,b,c])
    #print(result)
    #print('a:{},b:{},c:{}'.format(r_a,r_b,r_c))
    fetches = [a,b,c]
    _a,_b,_c = sess.run(fetches)
    print(_a,_b,_c)

tf.summary.FileWriter('./my_graph',sess.graph)

'''
import tensorflow as tf
t_0 = 50
t_1 = [1,2,3]
t_2 = [[1,2,3],[3,4,5]]
t_3 = [[[1,2,3],[4,5,6]],[[7,8,9],[2,3,5]]]

import numpy as np
a = np.array([2,3,4],dtype=np.int32)
b = np.array([2,3,4],dtype=np.int32)
c = np.array([2,3,4],dtype=np.int32)
print(tf.Session().run())
'''