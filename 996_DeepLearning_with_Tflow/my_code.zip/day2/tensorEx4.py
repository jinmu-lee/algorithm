import tensorflow as tf

a = tf.constant([3,4,5])
b = tf.reduce_prod(a)

sess = tf.InteractiveSession()
print(a.eval())
print(b.eval())