import pandas as pd
import numpy as np

data = np.array([4,7,0,2])
obj = pd.Series(data);
print(obj)
obj2 = pd.Series(data,index=['a','b','c','d'])

print(obj2)
print(obj2['b'])
print(obj2['b':'d'])
data2 = {'a':2,'b':5}
obj3 = pd.Series(data2)
print(obj3)

data3 = np.random.randn(2,2)
obj4 = pd.DataFrame(data3,columns=['x','y'],index=['one','two'])

print(obj4)
print('\n',obj4['x'])
print('\n',obj4.loc['one'])
print('\n',obj4.y)