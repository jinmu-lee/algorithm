import tensorflow as tf

print(tf.get_default_graph())
g = tf.Graph()
print(g)

with g.as_default():
    a = tf.multiply(2,4)
    b = tf.add(a,5)
    c = tf.subtract(b,7)
    print(tf.Session().run(c))

#tf.summary.FileWriter('./my_graph',sess.graph)
#tf.summary.FileWriter('./my_graph',sess.get_default_graph())
tf.summary.FileWriter('./my_graph',graph=g)



'''
a = tf.constant(10)
print(a.graph is g)
print(a.graph is tf.get_default_graph())
'''

'''
import tensorflow as tf

my_var = tf.Variable(1)
my_var_times_two = my_var.assign(my_var*2)

init = tf.global_variables_initializer()
sess = tf.Session()
sess.run(init)

print(sess.run(my_var_times_two))
print(sess.run(my_var_times_two))
print(sess.run(my_var_times_two))
'''

'''
import tensorflow as tf

input_data = [1,2,3,4,5]

x = tf.placeholder(dtype=tf.float32)
w = tf.Variable([2],dtype=tf.float32)
y = w*x

sess = tf.Session()
init = tf.global_variables_initializer() # w init
sess.run(init)
result = sess.run(y,feed_dict={x:input_data})
print(result)
'''
'''
import tensorflow as tf

x = tf.constant([[1.0,2.0,3.0]])
w = tf.constant([ [2.0],[2.0],[2.0] ])
y = tf.matmul(x,w)
print(x.get_shape())

sess = tf.Session()
init = tf.global_variables_initializer()
sess.run(init)
result = sess.run(y)

print(result)
'''