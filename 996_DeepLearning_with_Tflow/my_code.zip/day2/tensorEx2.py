import tensorflow as tf
import os

os.environ['TF_CPP_MIN_LOG_LEVEL']='2'

a = tf.constant(7, dtype=tf.int32, name='input_a')
b = tf.constant(3, dtype=tf.int32, name='input_b')
c = tf.constant(10, dtype=tf.int32, name='input_c')
d = tf.constant(20, dtype=tf.int32, name='input_d')

e = tf.multiply(a,b, name='multiply_e')
f = tf.add(e,c, name='add_f')
g = tf.subtract(f,d, name='subtract_g')

with tf.Session() as sess:
    result = sess.run(g)
    print(result)

tf.summary.FileWriter('./my_graph',sess.graph)