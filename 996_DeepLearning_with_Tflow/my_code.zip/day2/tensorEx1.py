import tensorflow as tf

a = tf.constant(5, dtype=tf.float32, name='input_a')
b = tf.constant(10, dtype=tf.float32, name='input_b')
c = tf.constant(2, dtype=tf.float32, name='input_c')
#d = a * b + c
d = tf.multiply(a,b, name='multiply_d')
e = tf.add(d,c, name='add_e')

print(a)
print(d)

sess = tf.Session()
result = sess.run(e)
print(result)

tf.summary.FileWriter('./my_graph', sess.graph)
sess.close()