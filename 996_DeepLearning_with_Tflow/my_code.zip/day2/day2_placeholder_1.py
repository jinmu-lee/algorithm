import tensorflow as tf
import numpy as np

np.random.seed(1234)
x_data = np.random.randn(5,10)
w_data = np.random.randn(10,1)

x = tf.placeholder(tf.float32,shape=(5,10))
w = tf.placeholder(tf.float32,shape=(10,1))
xw = tf.matmul(x,w) # matrix[5][10] * matrix[10][1]
b = tf.fill((5,1),-1.)
xwb = xw + b

max_value = tf.reduce_max(xwb)
sess = tf.Session()
result = sess.run(max_value,feed_dict={x:x_data, w:w_data})
print(result)

'''
import tensorflow as tf
import numpy as np

input_data = [[5,3],[4,7]]
a = tf.placeholder(dtype=tf.float32,shape=[2, 2],name='input_data')
b = tf.reduce_prod(a,name='prod_b')
c = tf.reduce_sum(a,name='sum_c')
d = tf.add(b,c,name='add_d')
sess = tf.Session()
in_dict = {a:np.array([[5,3],[4,7]],dtype=np.int32)}
fetches = [b,c,d]
_b,_c,_d = sess.run(fetches=fetches,feed_dict=in_dict)
print('b:{}, c:{}, d:{}'.format(_b,_c,_d))
'''
'''
y = x*2

sess = tf.Session()
result = sess.run(y,feed_dict={x:input_data})

print(result)
'''