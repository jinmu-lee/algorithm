import numpy as np

arr = np.arange(10)
print('\n',arr[5])
print('\n',arr[5:8])
arr[5:8] = 12
print('\n',arr)