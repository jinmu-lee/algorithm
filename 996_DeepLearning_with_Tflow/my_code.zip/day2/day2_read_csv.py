import pandas as pd

df = pd.read_csv('ex1.csv')
print(df)
print(type(df))

df2 = pd.read_csv('ex2.csv',header=None)
print(df2)
df2 = pd.read_csv('ex2.csv',names=['one','two','three','four','message'])

print('\n',df2)
df2 = pd.read_csv('ex2.csv',names=['one','two','three','four','message'])
print('\n',df2)

df3 = pd.read_csv('ex4.csv',skiprows=[0,2,3])
print(df3)
