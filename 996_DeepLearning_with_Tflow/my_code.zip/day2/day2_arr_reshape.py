import numpy as np

arr = np.arange(32)
print(arr)
print(arr.reshape((8,4)))
print(arr.reshape((8,4)))
