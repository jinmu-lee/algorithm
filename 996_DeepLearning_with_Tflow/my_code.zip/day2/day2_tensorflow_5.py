import tensorflow as tf



'''
import tensorflow as tf

with tf.name_scope("Scope_A"):
    a=tf.add(1,3,name='a_add')
    b=tf.multiply(a,3,name='a_multi')

with tf.name_scope("Scope_B"):
    c=tf.add(4,5,name='b_add')
    d=tf.multiply(c,7,name='b_multi')

print(tf.Session().run(b+d))
tf.summary.FileWriter('./my_graph',graph=tf.get_default_graph())
'''
'''
import tensorflow as tf
graph = tf.Graph()
with graph.as_default():
    in_1 = tf.placeholder(tf.float32,shape=[None,2],name='input_a')
    in_2 = tf.placeholder(tf.float32,shape=[None,2],name='input_b')
    const = tf.constant(2,dtype=tf.float32,name='static_value')

    with tf.name_scope('Transformation'):
        with tf.name_scope('A'):
            a_mul = tf.multiply(in_1,const)
            a_out = tf.subtract(a_mul,in_1)

        with tf.name_scope('B'):
            b_div = tf.div(a_)
            b_out = tf.subtract(a_mul,in_1)

        with tf.name_scope('C'):
            a_mul = tf.multiply(in_1, const)
            a_out = tf.subtract(a_mul, in_1)

        with tf.name_scope('D'):
            a_mul = tf.multiply(in_1, const)
            a_out = tf.subtract(a_mul, in_1)
'''