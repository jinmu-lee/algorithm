'''
import tensorflow as tf

a = tf.constant([3,4,5])
b = tf.reduce_prod(a)

sess = tf.InteractiveSession()
print(a.eval())
print(b.eval())
'''

import tensorflow as tf

a = tf.constant([[1,2,3],[4,5,6]])
b = tf.constant([1,0,1])
b = tf.expand_dims(b,1)
print('a_shape:',a.get_shape())
print('b_shape:',b.get_shape())
c = tf.matmul(a,b)

sess = tf.Session()
result = sess.run(c)
print('matrix multiply : \n{}'.format(result))
