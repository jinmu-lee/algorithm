import tensorflow as tf


x = tf.constant([[1., 2., 3.], [4., 5., 6.], [7., 8., 9.]])
y = tf.constant([[1., 1., 1.], [2., 2., 2.]])

'''
subXY = tf.sub(x,y)
sess = tf.Session()
result = sess.run(subXY)
print(result)
'''

expanded_X = tf.expand_dims(x, 0)
expanded_Y = tf.expand_dims(y, 1)
print('x => ',x.shape)
print('y => ',y.shape)
print('expanded_X => ',expanded_X.get_shape())
print('expanded_Y => ',expanded_Y.get_shape())

subXY = tf.subtract(expanded_X, expanded_Y)
sess = tf.Session()
result, _expanded_X, _expanded_Y = sess.run([subXY, expanded_X, expanded_Y])
print("\n",_expanded_X, "\n shape: \n", expanded_X.get_shape())
print("\n",_expanded_Y, "\n shape: \n", expanded_Y.get_shape())
print("\n", result, "\n shape: \n", subXY.get_shape())

