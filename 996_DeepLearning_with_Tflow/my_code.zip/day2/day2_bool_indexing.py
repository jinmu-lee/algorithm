import numpy as np
np.random.seed(1234)

names = np.array(['bob','joe','will','bob','will','joe','joe'])
data = np.random.rand(7,4)  # col : 7 , row : 4
print('\n',names,'\n')
print('\n',data)

print('\n',names=='bob')
print('\n',data[names=='bob'])

print('\n',data[names=='bob',2:]) #column matching
print('\n',data[names=='bob',3])  #column matching
