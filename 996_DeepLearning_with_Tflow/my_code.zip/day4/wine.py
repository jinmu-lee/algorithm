import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

Data_set =np.loadtxt("./data/wine.csv",delimiter=',')

x_data = Data_set[:,0:12]
y_data = Data_set[:,12]

X = tf.placeholder(tf.float32)
Y = tf.placeholder(tf.float32)

W1 = tf.Variable(tf.random_uniform([12,30],-1.,1.))
b1 = tf.Variable(tf.zeros([30]))
L1 = tf.add(tf.matmul(X,W1),b1)
L1 = tf.nn.sigmoid(L1)

W2 = tf.Variable(tf.random_uniform([30,1],-1.,1.))
b2 = tf.Variable(tf.zeros([1]))

model = tf.add(tf.matmul(L1,W2),b2)
cross_entropy = tf.nn.sigmoid_cross_entropy_with_logits(labels=Y,logits=model)
cost = tf.reduce_mean(cross_entropy)
optimizer = tf.train.AdadeltaOptimizer(learning_rate=0.01)
train_op = optimizer.minimize(cost)

init=tf.global_variables_initializer()
sess = tf.Session()
sess.run(init)

predicted = tf.cast(model > 0.5, dtype=tf.float32)
accuracy = tf.reduce_mean(tf.cast(tf.equal(predicted, y_data), dtype=tf.float32))

for step in range(2000):
    accuracyv,costv,_ = sess.run([accuracy,cost,train_op],feed_dict={X:x_data,Y:y_data})
    plt.title('multi line')
    if (step+1) % 100 == 0:
        print('cost:{0} '.format(costv))
        print('accuracy:',accuracyv)

        plt.plot(costv, costv, 'y--')
        plt.plot(accuracyv, accuracyv, 'g*:')

plt.show()
