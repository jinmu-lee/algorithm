import matplotlib.pyplot as plt
import numpy as np
'''
plt.title('plot')
plt.plot([1,4,9,16])
plt.show()

plt.title('plot2')
plt.plot([10,20,30,40],[1,4,9,16])
plt.show()

plt.title('style')
plt.plot([10,20,30,40],[1,4,9,16],'rs--')
plt.show()

plt.title('style')
plt.plot([10,20,30,40],[1,4,9,16],c='r',lw=5,ls='--',marker='o',ms=15,mew=5,mfc='g')
plt.show()

plt.title('style')
plt.plot([10,20,30,40],[1,4,9,16],'rs--')
plt.show()

plt.title('style')
plt.plot([10,20,30,40],[1,4,9,16],c='r',lw=5,ls='--',marker='o',ms=15,mew=5,mfc='g')
plt.show()
'''
data = np.arange(0.,5.,0.2)
plt.title('multi line')
plt.plot(data,data,'y--')
plt.plot(data,0.5*data**2,'g*:')
plt.show()



