import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

np.random.seed(777)
lr = 0.01

df_pre = pd.read_csv('wine.csv', header=None)
df = df_pre.sample(frac=0.15)

dataset = df.values
x_data = dataset[:, 0:12]
y_data = dataset[:,12].reshape(975,1)
print(y_data)


X = tf.placeholder(tf.float32, [None,12])
Y = tf.placeholder(tf.float32,[None,1])

w1 = tf.Variable(tf.random_normal([12,30]), name='weight1')
b1 = tf.Variable(tf.random_normal([30]),name='bias1')
layer1 = tf.sigmoid(tf.matmul(X, w1) + b1)

w2 = tf.Variable(tf.random_normal([30,12]), name='weight2')
b2 = tf.Variable(tf.random_normal([12]),name='bias2')
layer2 = tf.nn.relu(tf.matmul(layer1, w2) + b2)

w3 = tf.Variable(tf.random_normal([12,8]), name='weight3')
b3 = tf.Variable(tf.random_normal([8]),name='bias3')
layer3 = tf.nn.relu(tf.matmul(layer2, w3) + b3)

w4 = tf.Variable(tf.random_normal([8,1]), name='weight4')
b4 = tf.Variable(tf.random_normal([1]),name='bias4')
hypothesis = tf.sigmoid(tf.matmul(layer3, w4) + b4)


cost = -tf.reduce_mean(Y * tf.log(hypothesis) + (1 - Y) *
                       tf.log(1 - hypothesis))
train = tf.train.GradientDescentOptimizer(learning_rate=lr).minimize(cost)

predicted = tf.cast(hypothesis > 0.5, dtype=tf.float32)
accuracy = tf.reduce_mean(tf.cast(tf.equal(predicted, Y), dtype=tf.float32))

r_loss = []
r_acc = []
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())

    for step in range(10001):
        _= sess.run([train], feed_dict={X:x_data, Y:y_data})

        if step % 100 == 0:
            _cost, a = sess.run([cost, accuracy],
                               feed_dict={X: x_data, Y: y_data})
            r_acc.append(a)
            r_loss.append(_cost)
            print("step:",step,"\ncost: ", _cost, "\nAccuracy: ", a)

x_len = np.arange(len(r_acc))
plt.plot(x_len, r_loss, "o", c="red", markersize=3, label="loss")
plt.plot(x_len, r_acc, "o", c="blue", markersize=3, label="accuracy")
plt.ylim(0,1.1)
plt.legend(loc='best')
plt.show()