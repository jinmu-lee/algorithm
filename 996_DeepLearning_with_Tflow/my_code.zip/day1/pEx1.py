class AA:
    def __init__(self):
        print('AA Init function call')

class BB(AA):
    def __init__(self):
        super().__init__()
        print('BB Init function call')

bb = BB()