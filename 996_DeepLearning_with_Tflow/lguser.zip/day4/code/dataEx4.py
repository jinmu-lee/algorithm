import pandas as pd
import numpy as np

#시계열 데이터
data = pd.read_csv('macrodata.csv')
periods = pd.PeriodIndex(year=data.year, quarter=data.quarter, name='date')
data = pd.DataFrame(data.to_records(),
                    columns=pd.Index(['realgdp','infl','unemp'], name='item'),
                    index=periods.to_timestamp('D','end'))
ldata = data.stack().reset_index().rename(columns={0:'value'})
print('\n', data.head(10),'\n')
print('\n', ldata[:10],'\n')

pivoted = ldata.pivot('date','item','value')
print('\n', pivoted.head(),'\n')

ldata['value2'] = np.random.randn(len(ldata))
print('\n', ldata[:10],'\n')

pivoted = ldata.pivot('date', 'item')
print('\n', pivoted[:5],'\n')
