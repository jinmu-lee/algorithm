import pandas as pd

#개별화
ages = [20, 22, 25, 27, 21, 23, 37, 31, 61, 45, 41, 32]
bins = [18, 25, 35, 60, 100]
cats = pd.cut(ages, bins)
print(cats,'\n')
print(pd.cut(ages, bins, right=False),'\n')
print(pd.value_counts(cats),'\n')

#그룹 이름 지정
group_names = ['Youth', 'YoungAdult', 'MiddleAged', 'Senior']
print(pd.cut(ages, bins, labels=group_names),'\n')