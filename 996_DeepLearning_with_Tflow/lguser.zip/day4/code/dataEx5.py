import pandas as pd
import numpy as np

data = pd.DataFrame({'k1':['one'] *3 + ['two']*4,
                     'k2':[1,1,2,3,3,4,4]})
print('\n', data,'\n')
print('\n', data.duplicated(),'\n')
print('\n', data.drop_duplicates(),'\n')

data['v1'] = range(7)
print('\n', data,'\n')
print('\n', data.drop_duplicates(['k1']),'\n')
print('\n', data.drop_duplicates(['k1','k2'],keep='last'),'\n')


data = pd.DataFrame({'food':['bacon','pulled pork','bacon','Pastrami','corned beef',
                             'Bacon','pastrami','honey ham','nova lox'],
                     'ounces':[4,3,12,6,7.5,8,3,5,6]})
print('\n', data,'\n')

meat_to_animal = {
    'bacon':'pig',
    'pulled pork':'pig',
    'pastrami':'cow',
    'corned beef':'cow',
    'honey ham':'pig',
    'nova lox':'salmon'
}

data['animal'] = data['food'].map(str.lower).map(meat_to_animal)
print('\n', data,'\n')
print('\n', data['food'].map(lambda x:meat_to_animal[x.lower()]),'\n')


#치환

data = pd.Series([1.,-999., 2., -999., -1000., 3.])
print('\n', data,'\n')
print('\n',data.replace([-999, -1000], np.nan),'\n')
print('\n', data.replace({-999:np.nan, -1000:0}),'\n')

#축 색인 이름 바꾸기

data = pd.DataFrame(np.arange(12).reshape(3,4),
                    index=['Ohio','Colorado','New York'],
                    columns=['one','two','three','four'])
print(data.index.map(str.upper),'\n')
data.index = data.index.map(str.upper)
print(data,'\n')

print(data.rename(index=str.title, columns=str.upper),'\n')
print(data.rename(index={'OHIO':'INDIANA'},
                  columns={'three':'peekaboo'}))


#특이값 찾아 제외

np.random.seed(12345)
data = pd.DataFrame(np.random.randn(1000,4))
print('\n', data.describe(),'\n')
print('\n', data.head(5),'\n')

col = data[3]
print('\n', col,'\n')
print('\n', col[np.abs(col) > 3],'\n')
print('\n', data[(np.abs(data) > 3).any(axis = 1)],'\n')
data[(np.abs(data) > 3)] = np.sign(data) * 3
print('\n', data.describe(),'\n')