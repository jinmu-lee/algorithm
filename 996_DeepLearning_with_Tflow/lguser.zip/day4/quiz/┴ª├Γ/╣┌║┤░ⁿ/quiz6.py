# 6. 영양소 정보 분석하기 위해 아래와 같이 구성하세요
#
#  ㄱ. 음식의 영양소 정보를 nutrients =[] 에 저장하세요
#      - 영양소 리스트를 하나의 데이터프레임으로 변환하고 음식의 id를 위한 칼럼을 추가합니다.
#      - 데이터프레임을 리스트에 추가하세요
#      - 이 리스트를 concat 메서드를 사용해서 합치세요
#
#  ㄴ. 중복된 데이터를 제거하세요
#
#  ㄷ. 컬럼의 이름을 아래와 같이 바꾸세요
#      description => food
#      group => fgroup

import json
import pandas as pd
import matplotlib.pyplot as plt

plt.style.use('ggplot')

with open('foods-2011-10-03.json') as file:
    db = json.load(file)

df = pd.DataFrame(db)
nutrients = pd.DataFrame()
for id_, nutrient in zip(df['id'], df['nutrients']):
    nutrient_df = pd.DataFrame(nutrient)
    nutrient_df['id'] = id_
    nutrients = pd.concat([nutrients, nutrient_df], axis=0, sort=False)

print(nutrients.head(20))
