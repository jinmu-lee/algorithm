# 4. 음식의 이름(description)과 그룹(group), id, 제조사를 추출하여
#    column=['description', 'group', 'id', 'manufacturer']로 구성된 info 데이터 프레임을
#    구성하여 5개만 출력하세요

import json
import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('ggplot')


with open('foods-2011-10-03.json') as file:
    db = json.load(file)

df = pd.DataFrame(db)
info = pd.DataFrame(df[['description', 'group', 'id', 'manufacturer']],
                    columns=['description', 'group', 'id', 'manufacturer'])
print(info.head(5))