# 1. 데이터의 키의 갯 수가 몇개 인지 출력하세요
import json
import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('ggplot')


with open('foods-2011-10-03.json') as file:
    db = json.load(file)

df = pd.DataFrame(db)
print(len(df.columns))

