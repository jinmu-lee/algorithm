# 3. 음식 정보가 가지고 있는 키들 중 nutrients는 영양소에 대한 정보를 가지고 있다.
#    이 정보 만 가지고 있는 nutrients 데이터 프레임을 구성하여 7개 만 출력하세요
import json
import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('ggplot')


with open('foods-2011-10-03.json') as file:
    db = json.load(file)

df = pd.DataFrame(db)

nutrients = []
for nutrient in df['nutrients']:
    nutrients.extend(nutrient)

nutrient_df = pd.DataFrame(nutrients)
print(nutrient_df.head(7))
