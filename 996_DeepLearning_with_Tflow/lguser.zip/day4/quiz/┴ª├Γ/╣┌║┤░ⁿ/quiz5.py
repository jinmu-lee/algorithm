# 5. 음식 그룹의 분포를 출력하세요
import json
import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('ggplot')


with open('foods-2011-10-03.json') as file:
    db = json.load(file)

df = pd.DataFrame(db)

print(df['group'].groupby(df['group']).count())
