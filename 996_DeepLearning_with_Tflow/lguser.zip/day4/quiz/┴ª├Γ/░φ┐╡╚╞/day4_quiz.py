import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

db = json.load(open('foods-2011-10-03.json'))
df = pd.DataFrame(db)

#1.
print("1. Number of key in Data: ",df.count(axis=1).max(), '\n')
#2.
print("2. Key in data: ",df.columns,'\n')

#3.
print("3. Nutrients data in 0 to 6")
nut_df = pd.DataFrame(df['nutrients'])

for i in range(7):
    print(pd.DataFrame(nut_df.loc[i]['nutrients'], columns=['value','units','description','group']),'\n')

#4.
print("4. Food's info with description/Group/id/manufacturer",'\n')
info = pd.DataFrame(df[['description','group','id','manufacturer']], columns=['description','group','id','manufacturer'])
print(info[:5])

#5.
print("5. distribution of group,'\n")
gdata = pd.DataFrame(df['group'])
gdata['count'] = gdata.count(axis='columns')

gdata = gdata.groupby(gdata['group']).sum()
print(gdata)

fig = plt.figure()
ax = fig.add_subplot(1,1,1)
ax.bar(gdata.index, gdata['count'])
plt.setp(ax.get_xticklabels(), rotation=90, fontsize=8)

plt.show()

#6.
nutrients = []
nut_info = pd.DataFrame()

for i in nut_df['nutrients']:
    nutrients.append(i)

#print(nutrients[0])
nut_info = pd.DataFrame(nutrients[0], columns=['value', 'units', 'description', 'group'])
print(nut_info)
