import json
import pandas as pd
import matplotlib.pyplot as plt

db = json.load(open('foods-2011-10-03.json'))
data_frame = pd.DataFrame(db)

#1
print('1. 데이터의 키의 갯 수가 몇개 인지 출력하세요: ', print(len(data_frame.columns)), '\n')

#2
print('2. 음식 정보가 가지고 있는 키를 출력하세요: ', print(data_frame.columns.values), '\n')

#3
print('3. nutrients 데이터 프레임을 구성하여 7개 만 출력')
print(pd.DataFrame(db[0]['nutrients'])[:7], '\n')

#4
info = pd.DataFrame(db, columns=['description', 'group', 'id', 'manufacturer'])
print('4. info 데이터 프레임을 구성하여 5개만 출력')
print(info[:5], '\n')
#5
# print(info['id'].groupby(info['group']).count().index)
plt.style.use('ggplot')
groups = info['id'].groupby(info['group']).count().index
counts = info['id'].groupby(info['group']).count()

fig = plt.figure()
ax1 = fig.add_subplot(1, 1, 1)
ax1.bar(groups, counts, align='center', color='darkblue')
ax1.xaxis.set_ticks_position('bottom')
ax1.yaxis.set_ticks_position('right')
plt.xticks(groups, groups, rotation=90, fontsize='small')
plt.xlabel('Groups')
plt.ylabel('Count')
plt.title('Dist. of Groups')
plt.show()

#6

i=0
for d in db[:1000]:
    temp = pd.DataFrame(d['nutrients'])
    temp['id'] = d['id']
    if i==0:
        nutrients = temp
    else:
        nutrients = pd.concat([nutrients, temp])
    i = i+1
n1 = nutrients.drop_duplicates(['description'])

print('6. 영양소 정보 분석하기 위해 아래와 같이 구성하세요')
print(n1.rename(columns={'description':'food', 'group':'fgroup'}))
