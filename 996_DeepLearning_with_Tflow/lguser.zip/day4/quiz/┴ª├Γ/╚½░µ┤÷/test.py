import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt

db=json.load(open("foods-2011-10-03.json"))

db=pd.DataFrame(db)
print(len(db.columns))

print(db.info())
print(db.columns)

print(db['nutrients'][:7])


info=pd.DataFrame(db, columns=['description', 'group', 'id', 'manufacturer'])

print(info[:5])

data_frame = info['group']

#print(data_frame.drop_duplicates([1],keep='last'))

#fig,ax=plt.subplots(nrows=1,ncols=1)

#data_frame.plot(kind='bar', ax=ax, alpha=0.75, title='Bar Plot')
#data_frame.plot(kind='box', ax=ax, title='Box Plot')
#plt.show()