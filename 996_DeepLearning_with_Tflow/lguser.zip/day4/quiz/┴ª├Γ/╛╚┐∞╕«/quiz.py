import json
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

db = json.load(open('foods-2011-10-03.json'))

df = pd.DataFrame(db)
print('1. 데이터의 키의 갯 수가 몇개 인지 출력하세요:')
print(len(df.keys()), '개 \n')

print('2. 음식 정보가 가지고 있는 키를 출력하세요 :')
print(df.keys(),'\n')

#print(df['nutrients'][:3])
#sf = pd.Series(df['nutrients'][:].values)

#3.
nutri_df = pd.DataFrame(db[0]['nutrients'])
print(nutri_df[:7])

