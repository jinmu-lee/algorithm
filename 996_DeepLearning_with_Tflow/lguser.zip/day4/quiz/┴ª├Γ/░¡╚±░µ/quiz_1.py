import json
import pandas as pd
import matplotlib.pyplot as plt
def p(x, y=""):
    print(y, x, "\n")

db = json.load(open("foods-2011-10-03.json"))
p(len(db[0].keys()), "1. Number of keys: ")
print("2. Keys: ")
for key in db[0].keys():
    p(key, " - ")

# for data in db:
#     p(data["nutrients"])

df = pd.DataFrame(db)
p(db[0:7])



#{"value":25.18,"units":"g","description":"Protein","group":"Composition"},
#df = pd.DataFrame(db['nutrients'], columns=["units"])
# p(df)

