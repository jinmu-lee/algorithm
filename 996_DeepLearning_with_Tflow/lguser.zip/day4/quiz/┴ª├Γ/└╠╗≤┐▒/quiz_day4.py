import json
import pandas as pd
import matplotlib.pyplot as plt

db = json.load(open('foods-2011-10-03.json'))

#1
data = pd.DataFrame(db, columns=['id', 'description', 'tags', 'manufacturer', 'group', 'portions', 'nutrients'])
print(data.count())

#2
print(list(data), '\n')

#3.

print('\n', data['nutrients'].head(7),'\n')

#4
columns = ['description', 'group', 'id', 'manufacturer']
info = pd.DataFrame(db, columns=columns)
print(info[:5], '\n')

#5
print(data['group'].value_counts(), '\n')

plt.style.use('ggplot')

fig = plt.figure()
ax1 = fig.add_subplot(1,1,1)

data['group'].value_counts().plot(kind='bar', title='Food')
plt.setp(ax1.get_xticklabels(), rotation=50, fontsize=5)
plt.setp(ax1.get_yticklabels(), rotation=20, fontsize=2)

plt.show()
