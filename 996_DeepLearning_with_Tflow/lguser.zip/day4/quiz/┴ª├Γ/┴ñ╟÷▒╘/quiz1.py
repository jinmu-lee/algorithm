import json
import pandas as pd
import matplotlib.pyplot as plt

db = json.load(open('./data/foods-2011-10-03.json'))

ddb = pd.DataFrame(db)
print(ddb.head(1))

print('1. data key count : ', len(ddb.columns))

print()
print('2. data keys : ', [key for key in ddb.columns])

print()
nutrients = pd.DataFrame(ddb['nutrients'])
print('3. dataFrame with nutrients : \n', nutrients.head(7))

print()
aa = pd.DataFrame(ddb, columns=['description', 'group', 'id', 'manufacturer'])
print('4. group \n', aa.head(5))

print()
day4_5 = ddb.groupby(ddb['group']).count()
print('\n 5. : ', day4_5, '\n')

print()
print('6.')
nutrients = []
for data in db:
    nut = pd.DataFrame(data['nutrients']);
    nut['id'] = data['id']
    nutrients.append(nut)

nutrients = pd.concat(nutrients, ignore_index=True)
print('\n',nutrients,'\n')

#중복된 데이터를 제거한다.
print('\n',nutrients.duplicated().sum(),'\n')

nutrients = nutrients.drop_duplicates()
print(nutrients)