import json
import pandas as pd
import matplotlib.pyplot as plt

db = json.load(open('foods-2011-10-03.json'))

#데이터의 키 갯 수
print(len(db), '\n')

#음식 정보가 가지고 있는 키
print(db[0].keys(), '\n')

#nutrients 데이터 프레임을 구성하여 7개 만 출력
nutrients = pd.DataFrame(db[0]['nutrients'])
print('\n', nutrients[:7], '\n')

# info 데이터 프레임 구성('description', 'group', 'id', 'manufacturer') 5개 출력
functions = ['description', 'group', 'id', 'manufacturer']
info = pd.DataFrame(db, columns=functions)
print('\n', info[:5], '\n')

#음식 그룹의 분포 출력
print(pd.value_counts(info.group), '\n')

#음식영양소 정보 nutrients =[] 에 저장
nutrients=[]

for line in db:
    list=pd.DataFrame(line['nutrients'])
    list['id']=line['id']
    nutrients.append(list)

nutrients=pd.concat(nutrients)

#중복제거
nutrients=nutrients.drop_duplicates()

#컬럼이름 변경
name={'description':'food','group':'fgroup'}
nutrients=nutrients.rename(columns=name)
print(nutrients, '\n')
