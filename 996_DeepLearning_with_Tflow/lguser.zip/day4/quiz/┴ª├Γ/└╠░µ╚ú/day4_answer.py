import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

db = json.load(open('foods-2011-10-03.json'))
df = pd.DataFrame(db, columns=['id', 'description', 'tags', 'manufacturer', 'group', 'portions', 'nutrients'])


# 1. 데이터의 키의 갯 수가 몇개 인지 출력하세요
print(df.count(axis=1).mean(), '\n')


# 2. 음식 정보가 가지고 있는 키를 출력하세요
print(list(df), '\n')


# 3. 음식 정보가 가지고 있는 키들 중 nutrients는 영양소에 대한 정보를 가지고 있다.
#    이 정보 만 가지고 있는 nutrients 데이터 프레임을 구성하여 7개 만 출력하세요
df_nut = pd.DataFrame(df['nutrients'])
print(df_nut[:7], '\n')


# 4. 음식의 이름(description)과 그룹(group), id, 제조사를 추출하여
#    column=['description', 'group', 'id', 'manufacturer']로 구성된 info 데이터 프레임을
#    구성하여 5개만 출력하세요

info1 = pd.DataFrame(df['description'])
info2 = pd.DataFrame(df['group'])
info3 = pd.DataFrame(df['id'])
info4 = pd.DataFrame(df['manufacturer'])
info = pd.concat([info1, info2, info3, info4], axis=1)
print(info[:5], '\n')


# 5. 음식 그룹의 분포를 출력하세요
#print(df['group'].value_counts(), '\n')

plt.style.use('ggplot')

fig = plt.figure()
ax1 = fig.add_subplot(1,1,1)

df['group'].value_counts().plot(kind='bar', title='Group of Foods')
plt.setp(ax1.get_xticklabels(), rotation=85, fontsize=8)
plt.setp(ax1.get_yticklabels(), rotation=0, fontsize=10)
ax1.set_xlabel('Group')
ax1.set_ylabel('Counts')
ax1.xaxis.set_ticks_position('bottom')
ax1.yaxis.set_ticks_position('left')

plt.show()


# 6. 영양소 정보 분석하기 위해 아래와 같이 구성하세요
#
#  ㄱ. 음식의 영양소 정보를 nutrients =[] 에 저장하세요
#      - 영양소 리스트를 하나의 데이터프레임으로 변환하고 음식의 id를 위한 칼럼을 추가합니다.
#      - 데이터프레임을 리스트에 추가하세요
#      - 이 리스트를 concat 메서드를 사용해서 합치세요
#
#  ㄴ. 중복된 데이터를 제거하세요
#
#  ㄷ. 컬럼의 이름을 아래와 같이 바꾸세요
#      description => food
#      group => fgroup

nutrients = []
df1 = pd.DataFrame(nutrients)

for list in df['nutrients']:
    df2 = pd.DataFrame(list)
    new = pd.concat(df1, df2)
    #nutrients.append(df)

#print(nutrients[:10], '\n')
print(new[:10], '\n')

#df = pd.DataFrame(nutrients) #, columns=['value', 'units'])
#print(df[:3], '\n')

#print(type(nutrients), '\n')
#df = pd.DataFrame(nutrients, columns=['value', 'units'])
#print(type(df), '\n')
#print(df[:3], '\n')

#print(pd.DataFrame(nutrients[0]), '\n')
#print(pd.DataFrame(nutrients[1]), '\n')
#print(pd.DataFrame(nutrients[2]), '\n')