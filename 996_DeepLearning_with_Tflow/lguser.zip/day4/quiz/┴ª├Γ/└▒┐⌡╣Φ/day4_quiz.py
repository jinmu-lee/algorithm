'''
1. 데이터의 키의 갯 수가 몇개 인지 출력하세요

2. 음식 정보가 가지고 있는 키를 출력하세요

3. 음식 정보가 가지고 있는 키들 중 nutrients는 영양소에 대한 정보를 가지고 있다.
   이 정보 만 가지고 있는 nutrients 데이터 프레임을 구성하여 7개 만 출력하세요

4. 음식의 이름(description)과 그룹(group), id, 제조사를 추출하여
   column=['description', 'group', 'id', 'manufacturer']로 구성된 info 데이터 프레임을
   구성하여 5개만 출력하세요

5. 음식 그룹의 분포를 출력하세요

6. 영양소 정보 분석하기 위해 아래와 같이 구성하세요

 ㄱ. 음식의 영양소 정보를 nutrients =[] 에 저장하세요
     - 영양소 리스트를 하나의 데이터프레임으로 변환하고 음식의 id를 위한 칼럼을 추가합니다.
     - 데이터프레임을 리스트에 추가하세요
     - 이 리스트를 concat 메서드를 사용해서 합치세요

 ㄴ. 중복된 데이터를 제거하세요

 ㄷ. 컬럼의 이름을 아래와 같이 바꾸세요
     description => food
     group => fgroup


'''
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
db = json.load(open('foods-2011-10-03.json'))

#1. 데이터의 키의 갯 수가 몇개 인지 출력하세요
print('\n',len(db),'\n')
#2. 음식 정보가 가지고 있는 키를 출력하세요
data = pd.DataFrame(db, columns=['id','description','tags','manufacturer','group','portions','nutrients'])
print('\n',data.keys(),'\n')
#3. 음식 정보가 가지고 있는 키들 중 nutrients는 영양소에 대한 정보를 가지고 있다.
#이 정보 만 가지고 있는 nutrients 데이터 프레임을 구성하여 7개 만 출력하세요
nutrients_data = pd.DataFrame(data['nutrients'])
print('\n',nutrients_data.sample(7),'\n')
#4. 음식의 이름(description)과 그룹(group), id, 제조사를 추출하여
#   column=['description', 'group', 'id', 'manufacturer']로 구성된 info 데이터 프레임을
#   구성하여 5개만 출력하세요
info = data.drop(['tags','portions','nutrients'],axis='columns')
print('\n',info.sample(5),'\n')

#5. 음식 그룹의 분포를 출력하세요
print('\n',info['group'].get_values(),'\n')
'''
6. 영양소 정보 분석하기 위해 아래와 같이 구성하세요

 ㄱ. 음식의 영양소 정보를 nutrients =[] 에 저장하세요
     - 영양소 리스트를 하나의 데이터프레임으로 변환하고 음식의 id를 위한 칼럼을 추가합니다.
     - 데이터프레임을 리스트에 추가하세요
     - 이 리스트를 concat 메서드를 사용해서 합치세요

 ㄴ. 중복된 데이터를 제거하세요

 ㄷ. 컬럼의 이름을 아래와 같이 바꾸세요
     description => food
     group => fgroup
'''
#ㄱ.
nutrients_data['id'] = np.arange(len(nutrients_data))
df_3 = pd.concat([data, nutrients_data],axis=1)
print('\n',df_3.sample(7),'\n')
#ㄴ.
#ㄷ.
