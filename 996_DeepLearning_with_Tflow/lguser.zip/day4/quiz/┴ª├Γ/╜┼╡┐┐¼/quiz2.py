'''
2. 음식 정보가 가지고 있는 키를 출력하세요
'''
import numpy as np
import pandas as pd
import json

db = json.load(open('foods-2011-10-03.json'))
data = pd.DataFrame(db)
print(db[0].keys())