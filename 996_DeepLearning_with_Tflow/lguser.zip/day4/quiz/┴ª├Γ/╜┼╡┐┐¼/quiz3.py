'''
3. 음식 정보가 가지고 있는 키들 중 nutrients는 영양소에 대한 정보를 가지고 있다.
   이 정보 만 가지고 있는 nutrients 데이터 프레임을 구성하여 7개 만 출력하세요
'''
import numpy as np
import pandas as pd
import json

db = json.load(open('foods-2011-10-03.json'))
data = pd.DataFrame(db)
nutrients = pd.DataFrame(data[:]['nutrients'])
print('\n', nutrients[:7])

