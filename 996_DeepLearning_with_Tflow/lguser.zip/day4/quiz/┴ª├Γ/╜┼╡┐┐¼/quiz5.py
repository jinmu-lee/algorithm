'''
5. 음식 그룹의 분포를 출력하세요
'''
import numpy as np
import pandas as pd
import json
import matplotlib.pyplot as plt

db = json.load(open('foods-2011-10-03.json'))

data = pd.DataFrame(db)
grouping = data.groupby(['group'])['id'].count()
#print(grouping)
types = list(grouping.index.values)
#print(types)
amounts = list(grouping)
#print(amounts)

plt.style.use('ggplot')

types_index = range(len(types))

fig = plt.figure()
ax1 = fig.add_subplot(1,1,1)
ax1.bar(types_index, amounts, align='center', color='darkblue')
ax1.xaxis.set_ticks_position('bottom')
ax1.yaxis.set_ticks_position('left')
plt.xticks(types_index, types, rotation=90, fontsize='small')

plt.xlabel('Types')
plt.ylabel('Amount')
plt.title('Types of the Groups')

plt.savefig('group.png', dpi=400, bbox_inches='tight')
plt.show()

