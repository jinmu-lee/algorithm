import numpy as np
import pandas as pd
import json
'''
1. 데이터의 키의 갯 수가 몇개 인지 출력하세요
'''
db = json.load(open('foods-2011-10-03.json'))
print(len(db[0].keys()))

