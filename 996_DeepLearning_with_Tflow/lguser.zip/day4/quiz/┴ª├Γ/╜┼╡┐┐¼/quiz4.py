'''

4. 음식의 이름(description)과 그룹(group), id, 제조사를 추출하여
   column=['description', 'group', 'id', 'manufacturer']로 구성된 info 데이터 프레임을
   구성하여 5개만 출력하세요
'''
import numpy as np
import pandas as pd
import json

db = json.load(open('foods-2011-10-03.json'))

data = pd.DataFrame(db)
data2 = data.drop(['tags', 'nutrients', 'portions'], axis=1)
data3 = data2.reindex(columns=['description', 'group', 'id', 'manufacturer'])
print(data3[:5])
