import json
import pandas as pd
import matplotlib.pyplot as plt
db = json.load(open('foods-2011-10-03.json'))

df = pd.DataFrame(db)

print(len(df.keys()),'\n')
print(df.keys(), '\n')

nutrients = pd.DataFrame(df['nutrients'])
print(nutrients.head(7), '\n')


info = pd.DataFrame(df['description'], columns ='description')

print(type(df['nutrients']), '\n')

nutrients = []
df = pd.DataFrame(df['nutrients'])


nutrients.append(df)

df_1 = pd.concat(nutrients, axis=0)



print(type(nutrients), '\n')