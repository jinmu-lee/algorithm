import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

db = json.load(open('foods-2011-10-03.json'))
day4 = pd.DataFrame(db)
#print('\n raw data. : ', day4, '\n')

# 1.
print('\n 1. : ', day4.count(), '\n')

# 2.
count = 0
for i in day4.keys():
    count += 1
print('\n 2. : ', count, '\n')

# 3.
day4_3 = pd.DataFrame(day4['nutrients'])
#print('\n 3. : ', day4['nutrients']., '\n')
print('\n 3. : ', day4_3[:7], '\n')

# 4.
info = pd.DataFrame(day4, columns=['description', 'group', 'id', 'manufacturer'])
print('\n 4. : ', info[:5], '\n')

# 5.
day4_5 = day4.groupby(day4['group']).count()
print('\n 5. : ', day4_5, '\n')

# 6.
nutrients = pd.DataFrame(day4['nutrients'][:][0])

print('\n 6. : ', nutrients, '\n')
