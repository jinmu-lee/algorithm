import json
import pandas as pd
import matplotlib.pyplot as plt
db = json.load(open('foods-2011-10-03.json'))

# 데이터의 키의 갯수가 몇개인지...
print('\n',len(db),'\n')

# 키를 출력한다.
print('\n',db[0].keys(),'\n')
print('\n',db[0]['nutrients'][0],'\n')

#'nutrients는 사전의 리스트이며 각 항목은 한 가지 영양소에 대한 정보를 담고 있다.
nutrients = pd.DataFrame(db[0]['nutrients'])
print('\n',nutrients[:7],'\n')

#음식의 이름과 그룹, id, 제조사 추출

info_keys = ['description','group','id','manufacturer']
info = pd.DataFrame(db, columns=info_keys)
print('\n',info[:5],'\n')

print('\n',info.info(),'\n')

#음식 그룹의 분포를 확인할 수 있다.
print('\n',pd.value_counts(info.group)[:10],'\n')


# 영양소 정보 분석
# 1).음식의 영양소 정보를 테이블에 저장한다.
#   (1) 영양소 리스트를 하나의 DataFrame으로 변환하고, 음식의 id를 위한 칼럼을 추가한다.
#   (2) DataFrame을 리스트에 추가한다.
#   (3) 이 리스트를 concat 메서드를 사용해서 합친다.

nutrients = []

for rec in db:
    fnuts = pd.DataFrame(rec['nutrients'])
    fnuts['id'] = rec['id']
    nutrients.append(fnuts)

nutrients = pd.concat(nutrients, ignore_index=True)
print('\n',nutrients,'\n')

#중복된 데이터를 제거한다.
print('\n',nutrients.duplicated().sum(),'\n')

nutrients = nutrients.drop_duplicates()

#group과 description은 모두 DataFrame 객체이므로 쉽게 보기 위해 이름을 바꾼다.
col_mapping = {'description':'food',
               'group':'fgroup'}

info = info.rename(columns=col_mapping, copy=False)
print('\n',info.info(),'\n')

col_mapping = {'description':'nutrient',
               'group':'nutgroup'}
nutrients = nutrients.rename(columns=col_mapping, copy=False)
print('\n',nutrients,'\n')

#info객체를 nutrients 객체로 병합한다.

ndata = pd.merge(nutrients, info, on='id', how='outer')
print('\n',ndata.info(),'\n')
print('\n',ndata.loc[3000],'\n')

result = ndata.groupby(['nutrient', 'fgroup'])['value'].quantile(0.5)
result['Zinc, Zn'].sort_values().plot(kind='barh')
plt.show()
