import pandas as pd
import numpy as np
data = {'state': ['Ohio', 'Ohio', 'Ohio', 'Nevada', 'Nevada', 'Nevada'],
        'year': [2000, 2001, 2002, 2001, 2002, 2003],
        'pop': [1.5, 1.7, 3.6, 2.4, 2.9, 3.2]}
frame = pd.DataFrame(data)
print('\n',frame)
print('\n',pd.DataFrame(data, columns=['year', 'state', 'pop']))

frame2 = pd.DataFrame(data, columns=['year', 'state', 'pop', 'debt'],
                      index=['one', 'two', 'three', 'four',
                             'five', 'six'])
print('\n',frame2)
print('\n',frame2.columns)
print('\n',frame2['state'])
print('\n',frame2.year)
print('\n',frame2.loc['three'])
frame2['debt'] = 16.5
print('\n',frame2)
frame2['debt'] = np.arange(6.)
print('\n',frame2)

val = pd.Series([-1.2, -1.5, -1.7], index=['two', 'four', 'five'])
frame2['debt'] = val
print('\n',frame2)

pop = {'Nevada': {2001: 2.4, 2002: 2.9},
       'Ohio': {2000: 1.5, 2001: 1.7, 2002: 3.6}}
frame3 = pd.DataFrame(pop)
print('\n',frame3)
print('\n',frame3.T)

pdata = {'Ohio': frame3['Ohio'][:-1],
         'Nevada': frame3['Nevada'][:2]}
print('\n',pd.DataFrame(pdata))

frame3.index.name = 'year'
frame3.columns.name = 'state'
print('\n',frame3)
print('\n',frame3.values)
