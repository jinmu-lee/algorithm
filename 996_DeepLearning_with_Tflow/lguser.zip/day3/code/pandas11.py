import pandas as pd

price = pd.read_pickle('yahoo_price.pkl')
volume = pd.read_pickle('yahoo_volume.pkl')

print(price,'\n')
print(volume,'\n')

pdata = price.pct_change()
print(pdata.tail(),'\n')
print(pdata.MSFT.corr(pdata.IBM),'\n')
print(pdata.MSFT.cov(pdata.IBM),'\n')
print(pdata.corr(),'\n')
print(pdata.cov(),'\n')
print(pdata.corrwith(pdata.IBM))
