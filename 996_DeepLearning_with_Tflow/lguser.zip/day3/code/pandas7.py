import pandas as pd
import numpy as np
np.random.seed(12345)

frame = pd.DataFrame(np.random.randn(4,3), columns=list('bde'),
                     index=['Utah', 'Ohio', 'Texas', 'Oregon'])
print('\n',frame,'\n')

f = lambda x:x.max() - x.min()
print('\n',frame.apply(f),'\n')
print('\n',frame.apply(f, axis=1),'\n')

def f1(x):
    return pd.Series([x.min(), x.max()],
                     index=['min','max'])
print('\n',frame.apply(f1),'\n')

format = lambda x : '%.2f' % x
print('\n',frame.applymap(format),'\n')
print('\n',frame['e'].map(format),'\n')