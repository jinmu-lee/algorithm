import numpy as np
import pandas as pd

arr = np.arange(12).reshape((3,4))
print(arr,'\n')
print(np.concatenate([arr,arr], axis=1),'\n')
print(np.concatenate([arr,arr], axis=0),'\n')

s1 = pd.Series([0,1], index=['a','b'])
s2 = pd.Series([2,3,4], index=['c','d','e'])
s3 = pd.Series([5,6], index=['f','g'])
print(pd.concat([s1,s2,s3]),'\n')
print(pd.concat([s1,s2,s3], axis=1, sort=False),'\n')

s4 = pd.concat([s1*5, s3])
print(s4,'\n')
print(pd.concat([s1,s4], axis=1, sort=False),'\n')
print(pd.concat([s1,s4], axis=1, join='inner'),'\n')
print(pd.concat([s1,s4], axis=1, join_axes=[['a','c','b','e']]),'\n')

result = pd.concat([s1,s1,s3], keys=['one','two','three'])
print(result,'\n')
print(result.unstack(),'\n')

df1 = pd.DataFrame(np.arange(6).reshape((3,2)), index=list('abc'),
                   columns=['one','two'])
df2 = pd.DataFrame(np.arange(4).reshape((2,2)), index=list('ac'),
                   columns=['three','four'])
print(df1,'\n')
print(df2,'\n')
print(pd.concat([df1,df2], axis=1, keys=['level1','level2'], sort=False),'\n')


'''
a = pd.Series([np.nan, 2.5, np.nan, 3.5, 4.5, np.nan],
              index=['f', 'e', 'd', 'c', 'b', 'a'])
b = pd.Series(np.arange(len(a), dtype=np.float32),
              index=['f', 'e', 'd', 'c', 'b', 'a'])
b[-1] = np.nan
print(a, '\n')
print(b,'\n')
print(np.where(pd.isnull(a),b,a),'\n')

print(b[:-2].combine_first(a[2:]))

'''
