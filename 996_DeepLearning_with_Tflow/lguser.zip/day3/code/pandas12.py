import pandas as pd
import numpy as np

data = pd.Series([1, np.nan, 3.5, np.nan, 7])
print('\n',data,'\n')
print('\n',data.dropna(),'\n')
print('\n',data[data.notnull()],'\n')

np.random.seed(12345)
df = pd.DataFrame(np.random.randn(7,3))
df.iloc[:4, 1] = np.nan
print('\n',df,'\n')
df.iloc[:2,2] = np.nan
print('\n',df,'\n')

print('\n',df.fillna(0),'\n')
print('\n',df.fillna({1:0.5,2:-1}),'\n')
print('\n',df.fillna(method='backfill'),'\n')
print('\n',df.fillna(df.mean()),'\n')