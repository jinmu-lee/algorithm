import pandas as pd
import numpy as np

data = pd.DataFrame(np.arange(6).reshape((2,3)),
                    index=pd.Index(['Ohio','Colorado'],name='state'),
                    columns=pd.Index(['one','two','three'],name='number'))
print('\n',data, '\n')

result = data.stack()
print('\n',result, '\n')
print('\n',result.unstack(), '\n')

print('\n',result.unstack(level=0), '\n')
print('\n',result.unstack(level=1), '\n')
print('\n',result.unstack('state'), '\n')


s1 = pd.Series([0,1,2,3], index=list('abcd'))
s2 = pd.Series([4,5,6], index=list('cde'))
data2 = pd.concat([s1,s2], keys=['one','two'])
print(data2,'\n')
print(data2.unstack(),'\n')

df = pd.DataFrame({'left':result,'right':result+5},
                  columns=pd.Index(['left','right'], name='side'))
print(df,'\n')
print(df.unstack('state'),'\n')
print(df.unstack('state').stack('side'),'\n')