import pandas as pd
import numpy as np

obj = pd.Series(np.arange(4.), index=['a', 'b', 'c', 'd'])
print('\n',obj)
print('\n',obj['b'])
print('\n',obj[1])
print('\n',obj[2:4])
print('\n',obj[['b', 'a', 'd']])
print('\n',obj[[1, 3]])
print('\n',obj[obj < 2])
print('\n',obj['b':'c'])
obj['b':'c'] = 5
print('\n',obj)

data = pd.DataFrame(np.arange(16).reshape((4, 4)),
                    index=['Ohio', 'Colorado', 'Utah', 'New York'],
                    columns=['one', 'two', 'three', 'four'])
print('\n',data)
print('\n',data['two'])
print('\n',data[['three', 'one']])
print('\n',data[data['three'] > 5])
print('\n',data.loc['Colorado', ['two', 'three']])
print('\n',data.iloc[2, [3, 0, 1]])
print('\n',data.iloc[2])
print('\n',data.iloc[[1, 2], [3, 0, 1]])
print('\n',data.loc[:'Utah', 'two'])
print('\n',data.iloc[:, :3][data.three > 5])




