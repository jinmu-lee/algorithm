import pandas as pd
import numpy as np

obj = pd.Series(range(4), index=list('dabc'))
print(obj.sort_index(),'\n')

frame = pd.DataFrame(np.arange(8).reshape(2,4),
                     index=['three','one'],
                     columns=list('dabc'))
print(frame.sort_index(),'\n')
print(frame.sort_index(axis=1),'\n')
print(frame.sort_index(axis=1, ascending=False),'\n')

obj = pd.Series([4,7,-3,2])
print(obj.sort_values(),'\n')

obj = pd.Series([4, np.nan, 7, np.nan, -3, 2])
print(obj.sort_values(),'\n')

frame = pd.DataFrame({'b':[4,7,-3,2], 'a':[0,1,0,1]})
print(frame, '\n')
print(frame.sort_values(by='b'), '\n')
print(frame.sort_values(by=['a','b']), '\n')

