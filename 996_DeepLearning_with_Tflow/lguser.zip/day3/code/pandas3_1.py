import pandas as pd
import numpy as np

obj = pd.Series(range(3), index=['a','b','c'])
index = obj.index
print(index,'\n')
print(index[1:],'\n')

index = pd.Index(np.arange(3))
obj2 = pd.Series([1.5, -2.5, 0], index=index)
print(obj2,'\n')
print(obj2.index is index)