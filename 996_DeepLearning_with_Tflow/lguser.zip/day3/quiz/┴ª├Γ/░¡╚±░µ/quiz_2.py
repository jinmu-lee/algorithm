import pandas as pd
import numpy as np
import json

def p(x):
    print('\n', x, '\n')

df1 = pd.DataFrame({
'매출' : [10000000, 12000000, 9000000, 6000000, 8000000, 1100000],
'비용' : [15000000, 1300000, 1200000, 9000000, 9900000, 9500000]},
index = ['1월', '2월', '3월', '4월', '5월', '6월'])

f =lambda x:x['매출'] - x['비용']

result1 = df1.apply(f, axis=1)
result2 = pd.DataFrame(result1, columns=["이익"])
result3= pd.concat([df1, result2], axis=1)

df2 = pd.DataFrame({
'매출' : [13000000, 14000000, 17000000, 15400000, 16500000, 16600000],
'비용' : [11000000, 10400000, 11000000, 12100000, 9000000, 9500000]},
index = ['7월', '8월', '9월', '10월', '11월', '12월'])

result4 = df2.apply(f, axis=1)
result5 = pd.DataFrame(result4, columns=["이익"])
result6= pd.concat([df2, result5], axis=1)

result = pd.concat([result3, result6])
# p(result)

f =lambda x:x.sum()
summary1 = result.apply(f)
summary2 = pd.DataFrame(summary1, columns=["총 실적"])
summary3 = summary2.T
summary = pd.concat([result, summary3])
p(summary)

