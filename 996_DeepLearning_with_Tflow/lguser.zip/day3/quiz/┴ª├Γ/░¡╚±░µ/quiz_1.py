import pandas as pd
import numpy as np
import json

def p(x):
    print('\n', x, '\n')

df1 = pd.DataFrame({"key": range(5),
                  "data1": list("asdfg"),
                   "data2" : range(2, 7, 1),
                   "data3": list("zxcvg"),
                   "data4" : range(2, 7, 1)})

p(df1)

df2 = pd.DataFrame({"key": range(2, 7, 1),
                  "data1": list("qwert"),
                   "data6" : range(5),
                   "data7": list("zxcvg"),
                   "data8" : range(3,8,1)})

p(df2)

p(pd.merge(df1, df2, on='key', how="outer", suffixes=('_left', '_right')))