import pandas as pd
import numpy as np
import json

def p(x):
    print('\n', x, '\n')

df_score2 = pd.DataFrame({"반": list("AAABB"),
                        "번호": [1,2,3,1,2],
                        "국어": [90, 80, 60, 80, 70],
                        "영어":[80, 90, 70, 80, 70],
                        "수학": [90, 60, 60, 70, 90]})
p(df_score2)

p(df_score2.stack(level=0))