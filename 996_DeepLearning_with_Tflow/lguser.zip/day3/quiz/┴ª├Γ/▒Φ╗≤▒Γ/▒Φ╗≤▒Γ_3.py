# 3. A반 학생 5 명과 B반 학생 5 명의 국어, 영어, 수학 점수를 나타내는 데이터프레임 df_score2 을 다음과 같이 만든다.
# a. "반", "번호", "국어", "영어", "수학" 을 열로 가지는 데이터프레임을 만든다.
# b. 1 차 행 인덱스로 "반" 을 2 차 행 인덱스로 "번호" 을 가지는 데이터프레임으로 변형한다.
# c.위 데이터 프레임에 각 학생의 평균을 나타내는 행을 오른쪽에 추가한다.
# d.행 인덱스로 "번호" 을, 1 차 열 인덱스로 "국어", "영어", "수학" 을, 2 차 열 인덱스로 "반" 을 가지는 데이터프레임으로 변형한다.
# e.위 데이터 프레임에 각 반별 각 과목의 평균을 나타내는 행을 아래에 추가한다.

import pandas as pd
import numpy as np

score1 = pd.DataFrame(np.arange(70,95,1).reshape((5,5)), columns=['반', '번호', '국어', '영어', '수학'])
score1['반'] = 'A'
score2 = pd.DataFrame(np.arange(50,75,1).reshape((5,5)), columns=['반', '번호', '국어', '영어', '수학'])
score2['반'] = 'B'

df_score2 = pd.concat([score1, score2])
print('\n', df_score2, '\n')

b_result = df_score2.set_index(['반', '번호']).stack()
print('\n', b_result, '\n')

avg = pd.DataFrame(b_result.groupby(['반', '번호']).mean()).stack()

# print(avg['A'][71])
print(avg)
#
c_result = pd.merge(b_result, avg, on=['반', '번호'], )
# # print(c_result)


