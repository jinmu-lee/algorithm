# 1. 두 개의 데이터프레임을 만들고 merge 명령으로 합친다. 단 데이터프레임은 다음 조건을 만족해야 한다
#
#   a.각각 5 x 5 이상의 크기를 가진다.
#
#   b.공통 열을 하나 이상 가진다. 다만 공통 열의 이름은 서로 다르다.

import pandas as pd
import numpy as np

df1 = pd.DataFrame(np.arange(25).reshape((5,5)),
                   columns=['a', 'b', 'c', 'd', 'e'],
                   index=['one', 'two', 'three', 'four', 'five'])
df2 = pd.DataFrame(np.arange(25).reshape((5,5)),
                   columns=['f', 'g', 'h', 'i', 'j'],
                   index=['one', 'two', 'three', 'four', 'five'])
df2['g'] = df2['g']+1
df2['h'] = df2['h']+2

df3 = pd.merge(df1, df2, left_on='a', right_on='f')
print('df1: ')
print(df1)
print('\n', 'df2: ')
print(df2)
print('\n', 'Merge df1 and df2: ')
print(df3)