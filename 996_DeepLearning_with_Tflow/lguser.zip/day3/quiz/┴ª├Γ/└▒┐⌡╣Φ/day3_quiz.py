import pandas as pd
import numpy as np
'''
2. 두 개의 데이터프레임을 만들고 merge 명령으로 합친다. 단 데이터프레임은 다음 조건을 만족해야 한다

  a.각각 5 x 5 이상의 크기를 가진다.

  b.공통 열을 하나 이상 가진다. 다만 공통 열의 이름은 서로 다르다.

'''
data1 = pd.DataFrame(np.arange(25).reshape((5,5)),
                     index=pd.Index(['a', 'b', 'c', 'd', 'e']),
                     columns=pd.Index(['1', '2', '3', '4', '5']))
data1['1'] = 0
data2 = pd.DataFrame(np.arange(25).reshape((5,5)),
                     index=pd.Index(['a', 'b', 'c', 'd', 'e']),
                     columns=pd.Index(['1', '2', '3', '4', '5']))
data2['2'] = 0
print(pd.concat([data1,data2]),'\n')

'''
2. 어느 회사의 전반기(1월 ~ 6월) 실적을 나타내는 데이터프레임과 후반기(7월 ~ 12월) 실적을 나타내는 데이터프레임을 

    만든 뒤 합친다. 실적 정보는 "매출", "비용", "이익" 으로 이루어진다. (이익 = 매출 - 비용).

    또한 1년간의 총 실적을 마지막 행으로 덧붙인다.
'''
df1 = pd.DataFrame({
    '매출' : [10000000, 12000000, 9000000, 6000000, 8000000, 1100000],
    '비용' : [15000000, 1300000, 1200000, 9000000, 9900000, 9500000]},
    index = ['1월', '2월', '3월', '4월', '5월', '6월'])

df2 = pd.DataFrame({
    '매출' : [13000000, 14000000, 17000000, 15400000, 16500000, 16600000],
    '비용' : [11000000, 10400000, 11000000, 12100000, 9000000, 9500000]},
    index = ['7월', '8월', '9월', '10월', '11월', '12월'])
print('실적 정보\n')
df3 = pd.concat([df1,df2])
print(df3,'\n')
earn = df3['매출']
price = df3['비용']
income = earn - price
print('이익\n')
print(np.sum(income),'\n')


'''
3. A 반 학생 5명과 B반 학생 5명의 국어, 영어, 수학 점수를 나타내는 데이터프레임 df_score2 을 다음과 같이 만든다.

   a. "반", "번호", "국어", "영어", "수학" 을 열로 가지는 데이터프레임을 만든다.

   b. 1차 행 인덱스로 "반"을 2차 행 인덱스로 "번호"을 가지는 데이터프레임으로 변형한다.

   c. 위 데이터 프레임에 각 학생의 평균을 나타내는 행을 오른쪽에 추가한다.

   d. 행 인덱스로 "번호"을, 1차 열 인덱스로 "국어", "영어", "수학"을, 2차 열 인덱스로 "반"을 가지는 데이터프레임으로 변형한다.
 
   e. 위 데이터 프레임에 각 반별 각 과목의 평균을 나타내는 행을 아래에 추가한다.
'''
#a
df_A = pd.DataFrame(np.arange(25).reshape((5, 5)),
                    index=pd.Index(['a', 'b','c', 'd','e'], name='name'),
                    columns=pd.Index(["반", "번호", "국어", "영어", "수학"], name='title'))
df_B = pd.DataFrame(np.arange(25).reshape((5, 5)),
                    index=pd.Index(['f', 'g','h', 'i','j'], name='name'),
                    columns=pd.Index(["반", "번호", "국어", "영어", "수학"], name='title'))
df_A['반']['a':'e'] = 'A'
df_B['반']['f':'j'] = 'B'
df_score2 = pd.concat([df_A,df_B])
print('\n',df_score2)
#b

df_score3 = df_score2.set_index(["반", "번호"])
print('\n',df_score3)


#c

scores = df_score2.drop(['반','번호'],axis='columns')
mean_scores = scores.mean(axis=1)
df_score4 = pd.concat([df_score2,mean_scores.rename('평균')],axis='columns')

print('\n',df_score4)

#d
df_score5 = df_score2.set_index(["번호"])
df_score5 = df_score5[["국어", "영어", "수학","반"]]
print('\n',df_score5)

#e
df_score6 = df_score2.drop(['반','번호'],axis='columns')
data_A = df_score6[0:5]
data_B = df_score6[5:10]
mean_A = data_A.mean(axis=0)
mean_B = data_B.mean(axis=0)
print(mean_A)
print(mean_B)