#1. 두 개의 데이터프레임을 만들고 merge 명령으로 합친다. 단 데이터프레임은 다음 조건을 만족해야 한다
#
#  a.각각 5 x 5 이상의 크기를 가진다.
#
#  b.공통 열을 하나 이상 가진다. 다만 공통 열의 이름은 서로 다르다.

import numpy as np
import pandas as pd

df1 = pd.DataFrame(np.random.randint(1,25,(5,5),'i'), index=pd.Index(list('abcde'), name='ind'), columns=pd.Index(list('ABCDE'), name='col'))
df2 = pd.DataFrame(np.random.randint(1,25,(5,5),'i'), index=pd.Index(list('fghij'), name='ind'), columns=pd.Index(list('FGHIJ'), name='col'))
df1['A'] = list('qwert')
df2['F'] = list('trewq')

print(df1,'\n')
print(df2,'\n')
print(pd.merge(df1,df2, left_on='A', right_on='F', how='outer'))