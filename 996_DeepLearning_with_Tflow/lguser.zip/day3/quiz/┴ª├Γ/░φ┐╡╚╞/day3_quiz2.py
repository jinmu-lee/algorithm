import numpy as np
import pandas as pd

df1 = pd.DataFrame({
    '매출': [10000000, 12000000, 9000000, 6000000, 8000000, 1100000],
    '비용': [15000000, 1300000, 1200000, 9000000, 9900000, 9500000]},
    index=['1월', '2월', '3월', '4월', '5월', '6월'])

df2 = pd.DataFrame({
    '매출': [13000000, 14000000, 17000000, 15400000, 16500000, 16600000],
    '비용': [11000000, 10400000, 11000000, 12100000, 9000000, 9500000]},
    index=['7월', '8월', '9월', '10월', '11월', '12월'])

f = lambda x:x['매출']-x['비용']
#f1 = lambda x:x.sum()

res = pd.concat([df1, df2])
res['이익'] = res.apply(f, axis='columns')
#sum = res.apply(f1)
#res = res.append(sum, ignore_index=True)

df = pd.DataFrame({'총계':res.sum(axis=0)})
print(df)
res = pd.concat([res,df.T])

print(res)