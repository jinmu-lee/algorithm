import numpy as np
import pandas as pd

data = {'반':[1,1,1,1,1,2,2,2,2,2], '번호':[1,2,3,4,5,1,2,3,4,5], '국어':np.random.randint(10,100,10),
        '영어': np.random.randint(10, 100, 10),'수학':np.random.randint(10,100,10)}

df_score2 = pd.DataFrame(data)
df_score2 = df_score2.set_index(['반','번호'])

df_score2['평균'] = df_score2.mean(axis=1)

print(df_score2)