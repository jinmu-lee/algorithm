import numpy as np
import pandas as pd


# 1. 두 개의 데이터프레임을 만들고 merge 명령으로 합친다. 단 데이터프레임은 다음 조건을 만족해야 한다
#
#   a.각각 5 x 5 이상의 크기를 가진다.
#
#   b.공통 열을 하나 이상 가진다. 다만 공통 열의 이름은 서로 다르다.

df1 = pd.DataFrame(np.arange(25).reshape(5,5), columns=pd.Index(['Bob', 'Will', 'James', 'Tomas', 'Peter']))
df2 = pd.DataFrame(np.arange(56).reshape(7,8), columns=pd.Index(['Kevin', 'Lily', 'Aaron', 'Athor', 'Chris', 'Mia', 'JJ', 'Anakin']))
df3 = pd.merge(df1, df2, left_on=['James'], right_on=['Aaron'])
print(df1, '\n')
print(df2, '\n')
print(df3, '\n')