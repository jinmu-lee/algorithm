import pandas as pd
import numpy as np

df_score2 = pd.DataFrame({
    '반': [ 'A', 'A', 'A', 'A', 'A', 'B', 'B', 'B', 'B', 'B'],
    '번호': [1, 2, 3, 4, 5, 1, 2, 3, 4, 5],
    '국어': [10, 20 ,30, 40, 50, 60 ,70 ,80 ,90 ,100],
    '영어': [100, 90, 80, 70, 60, 50, 40, 30, 20, 10],
    '수학': [50, 55, 60, 65, 70, 75, 80, 85, 90, 95]})

print(df_score2, '\n')

df_a = df_score2.stack()

print(df_a, '\n')

print(df_score2.mean(), '\n')

