import pandas as pd
import numpy as np

"""
1. 두 개의 데이터프레임을 만들고 merge 명령으로 합친다. 단 데이터프레임은 다음 조건을 만족해야 한다

  a.각각 5 x 5 이상의 크기를 가진다.

  b.공통 열을 하나 이상 가진다. 다만 공통 열의 이름은 서로 다르다.
"""
d1 = pd.DataFrame({'key1':['foo', 'foo', 'bar', 'foo', 'bar'],
                     'key2':['one','two', 'one', 'two', 'one'],
                     'key3':[1,2,3,4,5],
                   'key4':[6,7,8,9,10],
                   'key5':['a', 'b', 'c', 'd', 'e']})

d2 = pd.DataFrame({'key6':['foo', 'foo', 'foo', 'foo', 'foo'],
                     'key7':['one','one', 'one', 'one', 'one'],
                     'key8':[-1,-2,-3,-4,-5],
                   'key9':[-6,-7,-8,-9,-10],
                   'key10':['a', 'b', 'c', 'd', 'e']})
print('\n', d1, '\n')
print('\n', d2, '\n')
print('\n', pd.merge(d1, d2, left_on='key5', right_on='key10'), '\n')

