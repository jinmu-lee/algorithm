# 1. 두 개의 데이터프레임을 만들고 merge 명령으로 합친다. 단 데이터프레임은 다음 조건을 만족해야 한다
#   a.각각 5 x 5 이상의 크기를 가진다.
#   b.공통 열을 하나 이상 가진다. 다만 공통 열의 이름은 서로 다르다.

import pandas as pd
import numpy as np

np.random.seed(12345)
pdata_1 = {
    "이름": ["철수", "영희", "수현", "건우", "재민"],
    '수학': np.random.randint(50, 100, 5),
    '물리': np.random.randint(50, 100, 5),
    '화학': np.random.randint(50, 100, 5),
    '생물': np.random.randint(50, 100, 5)
}
pdata_2 = {
    "성명": ["철수", "영희", "수현", "건우", "재민"],
    '지리': np.random.randint(50, 100, 5),
    '문학': np.random.randint(50, 100, 5),
    '영어': np.random.randint(50, 100, 5),
    '윤리': np.random.randint(50, 100, 5)
}
df_1 = pd.DataFrame(pdata_1, columns=['이름', '수학', '물리', '화학', '생물'])
df_2 = pd.DataFrame(pdata_2, columns=['성명', '지리', '문학', '영어', '윤리'])

df_merge = pd.merge(df_1, df_2, left_on='이름', right_on='성명')

print(df_merge)
