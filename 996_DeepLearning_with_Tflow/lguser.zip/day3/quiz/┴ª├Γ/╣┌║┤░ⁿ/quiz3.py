# 3. A 반 학생 5명과 B반 학생 5명의 국어, 영어, 수학 점수를 나타내는 데이터프레임 df_score2 을 다음과 같이 만든다.
#    a. "반", "번호", "국어", "영어", "수학" 을 열로 가지는 데이터프레임을 만든다.
#    b. 1차 행 인덱스로 "반"을 2차 행 인덱스로 "번호"을 가지는 데이터프레임으로 변형한다.
#    c. 위 데이터 프레임에 각 학생의 평균을 나타내는 행을 오른쪽에 추가한다.
#    d. 행 인덱스로 "번호"을, 1차 열 인덱스로 "국어", "영어", "수학"을, 2차 열 인덱스로 "반"을 가지는 데이터프레임으로 변형한다.
#    e. 위 데이터 프레임에 각 반별 각 과목의 평균을 나타내는 행을 아래에 추가한다.

import pandas as pd
import numpy as np

np.random.seed(12345)

pdata = {
    "반": [1, 1, 1, 1, 1, 2, 2, 2, 2, 2],
    '번호': [1, 2, 3, 4, 5, 1, 2, 3, 4, 5],
    '국어': np.random.randint(70,100,10),
    '영어': np.random.randint(70,100,10),
    '수학': np.random.randint(70,100,10)
}

df_score2 = pd.DataFrame(pdata, columns=["반", '번호', '국어', '영어', '수학'])
print("a.\n", df_score2,"\n")
df = df_score2.set_index(['반', '번호'])
print("b.\n", df, "\n")

mean = pd.DataFrame(df.mean(axis=1), columns=["평균"])
df = pd.concat([df, mean], axis=1)
