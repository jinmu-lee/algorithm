import pandas as pd
import numpy as np

frame1 = pd.DataFrame({'a':[1,2,3,4,5], 'b': range(5), 'c': np.random.randn(5), 'd': np.random.randn(5), 'e': np.random.randn(5)})
frame2 = pd.DataFrame({'f':[1,2,3,4,5], 'g': range(5), 'h': np.random.randn(5), 'i': np.random.randn(5), 'j': np.random.randn(5)})


print(pd.merge(frame1, frame2, left_on='a', right_on="f"))
