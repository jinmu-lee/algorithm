import pandas as pd
import numpy as np

df1 = pd.DataFrame(np.arange(25).reshape(5,5), columns=['a','b','c','d','e'])
df2 = pd.DataFrame(np.arange(25).reshape(5,5), columns=['b','e','g','h','i'])

print('\n',df1,'\n')
print('\n',df2, '\n')

print('\n',pd.merge(df1,df2), '\n')
