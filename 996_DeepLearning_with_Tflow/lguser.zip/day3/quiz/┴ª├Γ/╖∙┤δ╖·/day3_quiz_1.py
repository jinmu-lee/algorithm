#1. 두 개의 데이터프레임을 만들고 merge 명령으로 합친다. 단 데이터프레임은 다음 조건을 만족해야 한다
#  a.각각 5 x 5 이상의 크기를 가진다.
#  b.공통 열을 하나 이상 가진다. 다만 공통 열의 이름은 서로 다르다.

import pandas as pd
import numpy as np

df1 =pd.DataFrame({'key1':['a','b','c','d','e'],
                   'data1':range(5),
                   'data2':range(4,9,1),
                   'data3':range(10,15,1),
                   'data4':range(9,4,-1),
                   })
df2 =pd.DataFrame({'key2':['c','d','e','f','g'],
                   'data5':range(5),
                   'data6':range(7,12,1),
                   'data7':range(5,10,1),
                   'data8':range(12,7,-1),
                   })
print('\n', pd.merge(df1, df2, left_on='key1', right_on='key2'))
