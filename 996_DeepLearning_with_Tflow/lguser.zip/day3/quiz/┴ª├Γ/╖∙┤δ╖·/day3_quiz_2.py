#2. 어느 회사의 전반기(1월 ~ 6월) 실적을 나타내는 데이터프레임과 후반기(7월 ~ 12월) 실적을 나타내는 데이터프레임을
#만든 뒤 합친다. 실적 정보는 "매출", "비용", "이익" 으로 이루어진다. (이익 = 매출 - 비용).
#또한 1년간의 총 실적을 마지막 행으로 덧붙인다.
import pandas as pd
import numpy as np

df1 = pd.DataFrame({
    '매출': [10000000, 12000000, 9000000, 6000000, 8000000, 1100000],
    '비용': [15000000, 1300000, 1200000, 9000000, 9900000, 9500000]},
    index=['1월', '2월', '3월', '4월', '5월', '6월'])

df2 = pd.DataFrame({
    '매출': [13000000, 14000000, 17000000, 15400000, 16500000, 16600000],
    '비용': [11000000, 10400000, 11000000, 12100000, 9000000, 9500000]},
    index=['7월', '8월', '9월', '10월', '11월', '12월'])

df1_이익 = df1.매출-df1.비용
df1_merge = pd.concat([df1, df1_이익], axis=1)
print('\n', df1_merge)

df2_이익 = df2.매출-df2.비용
df2_merge = pd.concat([df2, df2_이익], axis=1)
print('\n', df2_merge)

merge = pd.concat([df1_merge, df2_merge])
print('\n', merge)

sum = merge.sum()

total_merge = pd.concat([merge, sum])
print('\n', total_merge)

