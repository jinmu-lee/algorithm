import pandas as pd
import numpy as np

df1 = pd.DataFrame({
    '매출': [10000000, 12000000, 9000000, 6000000, 8000000, 1100000],
    '비용': [15000000, 1300000, 1200000, 9000000, 9900000, 9500000]},
    index=['1월', '2월', '3월', '4월', '5월', '6월'])

df2 = pd.DataFrame({
    '매출': [13000000, 14000000, 17000000, 15400000, 16500000, 16600000],
    '비용': [11000000, 10400000, 11000000, 12100000, 9000000, 9500000]},
    index=['7월', '8월', '9월', '10월', '11월', '12월'])

print(df1, '\n')
print(df2, '\n')


df1_profit = df1['매출'] - df1['비용']
df1_profit = pd.DataFrame({'이익':df1_profit})

print(df1_profit, '\n')
df1 = pd.concat([df1, df1_profit], axis=1)

df2_profit = df2['매출'] - df2['비용']
df2_profit = pd.DataFrame({'이익':df2_profit})

print(df2_profit, '\n')
df2 = pd.concat([df2, df2_profit], axis=1)

df3 = pd.concat([df1,df2], axis=0)

total = pd.concat([df3, df3.sum()])

print(total, '\n')
