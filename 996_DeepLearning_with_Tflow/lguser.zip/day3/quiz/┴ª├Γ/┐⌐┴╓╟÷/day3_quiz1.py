import pandas as pd
import numpy as np


left = pd.DataFrame({'key1':['foo', 'foo', 'bar', 'one', 'two'],
                     'key2':['one', 'two', 'one', 'two', 'three'],
                     'key3':['bar', 'foo', 'one', 'two', 'foo'],
                     'key4':['three', 'four', 'foo', 'one', 'bar'],
                     'lval':[1,2,3,4,5]})
right = pd.DataFrame({'key5':['foo', 'foo', 'bar', 'bar', 'one'],
                      'key6': ['one', 'two', 'one', 'two', 'three'],
                      'key7': ['bar', 'foo', 'one', 'two', 'foo'],
                      'key8': ['one', 'one', 'one', 'two', 'three'],
                      'rval':[4,5,6,7,8]})

print(left, '\n')
print(right, '\n')
print(pd.merge(left, right, left_on='key2', right_on='key7'), '\n')

#data1 = pd.DataFrame()