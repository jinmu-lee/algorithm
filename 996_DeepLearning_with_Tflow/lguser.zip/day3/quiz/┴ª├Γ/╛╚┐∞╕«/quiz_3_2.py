import pandas as pd
import numpy as np

df1 = pd.DataFrame({
    '매출' : [10000000, 12000000, 9000000, 6000000, 8000000, 1100000],
    '비용' : [15000000, 1300000, 1200000, 9000000, 9900000, 9500000]},
    index = ['1월', '2월', '3월', '4월', '5월', '6월'])

df2 = pd.DataFrame({
    '매출' : [13000000, 14000000, 17000000, 15400000, 16500000, 16600000],
    '비용' : [11000000, 10400000, 11000000, 12100000, 9000000, 9500000]},
    index = ['7월', '8월', '9월', '10월', '11월', '12월'])

total_df = pd.concat([df1,df2])
#print(total_df,'\n')
s1 = pd.Series(df1['매출']-df1['비용'])
s2 = pd.Series(df2['매출']-df2['비용'])

s3 = pd.concat([s1,s2], sort = False)
df3 = pd.DataFrame({
    '이익':s3},
)

df = pd.merge(total_df, df3, on=total_df.index, sort = False)


total_s = pd.DataFrame({
    '매출':[np.sum(df['매출'])],
    '비용':[np.sum(df['비용'])],
    '이익':[np.sum(df['이익'])]},
    index = ['총실적']

)


return_df = pd.concat([df, total_s])
print(return_df,'\n')