import numpy as np
import pandas as pd

df_score2 = pd.DataFrame({
    '반':[2,2,3,2,1,1,4],
    '번호':[13,22,14,5,24,22,3],
    '국어':[90,77,100,66,86,75,98],
    '영어':[90,79,66,98,100,79,88],
    '수학':[98,99,70,88,100,70,92],
}
)

print(df_score2)
print('$$$$$$$$$$$$$$$')

print(df_score2.stack().keys())
print(df_score2.stack().columns())