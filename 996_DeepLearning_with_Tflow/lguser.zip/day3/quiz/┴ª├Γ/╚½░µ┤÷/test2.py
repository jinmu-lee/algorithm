import pandas as pd
import numpy as np
import json

data1=pd.DataFrame(np.arange(25).reshape(5,5),
                  index=pd.Index(['i1','i2','i3','i4','i5'], name='index'),
                  columns=pd.Index(['c1','c2','c3','c4','c5'],name='column'))

data2=pd.DataFrame(np.arange(25).reshape(5,5),
                  index=pd.Index(['i1','i2','i3','i4','i5'], name='index2'),
                  columns=pd.Index(['c1','c2','c3','c4','c5'],name='column2'))

print(data1)
print(data2)
print(pd.merge(data1,data2, left_on='c1', right_on='c1'))