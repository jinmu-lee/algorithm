import pandas as pd
import numpy as np
import json

df1 = pd.DataFrame({
    '매출': [10000000, 12000000, 9000000, 6000000, 8000000, 1100000],
    '비용': [15000000, 1300000, 1200000, 9000000, 9900000, 9500000]},
    index=['1월', '2월', '3월', '4월', '5월', '6월'])

df2 = pd.DataFrame({
    '매출': [13000000, 14000000, 17000000, 15400000, 16500000, 16600000],
    '비용': [11000000, 10400000, 11000000, 12100000, 9000000, 9500000]},
    index=['7월', '8월', '9월', '10월', '11월', '12월'])

df3= pd.concat([df1,df2])
print(df3)
df4=pd.DataFrame({'이익': df3['매출']-df3['비용']}, index=['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'])

df5 = pd.concat([df3,df4], axis=1)
print(df5)

#df6=pd.DataFrame(df5['매출'].sum(),df5['비용'].sum(),df5['이익'].sum() )
print(df5.sum())


s1=pd.Series([0,1], index=['a','b'])
s2=pd.Series([2,3,4], index=['c','d','e'])
s3=pd.Series([5,6], index=['f','g'])
print(pd.concat([s1,s2,s3]))
