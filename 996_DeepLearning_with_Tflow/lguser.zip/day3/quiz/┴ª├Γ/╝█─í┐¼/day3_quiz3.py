import pandas as pd
import numpy as np

df_score2 = pd.DataFrame({
    '반': ['A', 'A', 'A', 'A', 'A', 'B', 'B', 'B', 'B', 'B'],
    '번호': [1,2,3,4,5,1,2,3,4,5],
    '국어' : [80, 92, 85, 90, 75, 90, 86, 92, 84, 90],
    '영어' : [88, 84, 90, 94, 85, 80, 92, 85, 90, 75],
    '수학' : [90, 86, 92, 84, 90, 88, 84, 90, 94, 85]})

print('\n', df_score2,'\n')

df_score2 = df_score2.set_index(['반','번호'])
print('\n', df_score2,'\n')

df_score2 = pd.concat([df_score2, pd.DataFrame({'평균': df_score2.mean(axis=1)})], axis=1)
print('\n', df_score2, '\n')

df_score2 = df_score2.unstack('반')
print('\n', df_score2, '\n')

df_score2.loc["평균",:] = df_score2.mean()
print('\n', df_score2, '\n')


