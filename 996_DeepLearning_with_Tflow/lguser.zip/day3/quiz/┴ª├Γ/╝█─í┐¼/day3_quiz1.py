import pandas as pd
import numpy as np

df1 = pd.DataFrame({'a':np.random.randn(5),
                    'b':[0,1,2,0,1],
                    'c': np.random.randn(5),
                    'd':[1,0,2,1,0],
                    'e': np.random.randn(5)})

df2 = pd.DataFrame({'f':[0,1,2,0,1],
                    'g':np.random.randn(5),
                    'h': np.random.randn(5),
                    'i':np.random.randn(5),
                    'j': [1,0,2,1,0]})

print('\n', df1, '\n')
print('\n', df2, '\n')
print('\n', pd.merge(df1, df2, left_on='b', right_on='f'), '\n')
