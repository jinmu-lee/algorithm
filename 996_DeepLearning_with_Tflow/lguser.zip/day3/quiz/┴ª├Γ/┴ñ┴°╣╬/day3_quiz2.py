import pandas as pd
import numpy as np

df1 = pd.DataFrame({
    '매출': [10000000, 12000000, 9000000, 6000000, 8000000, 1100000],
    '비용': [15000000, 1300000, 1200000, 9000000, 9900000, 9500000]},
    index=['1월', '2월', '3월', '4월', '5월', '6월'])

df2 = pd.DataFrame({
    '매출': [13000000, 14000000, 17000000, 15400000, 16500000, 16600000],
    '비용': [11000000, 10400000, 11000000, 12100000, 9000000, 9500000]},
    index=['7월', '8월', '9월', '10월', '11월', '12월'])

sumdata = pd.concat([df1,df2], axis=0, sort=False, join='inner')
sumdata['이익'] = sumdata['매출'] - sumdata['비용']
# print('\n', sumdata, '\n')
# print('\n', sumdata.sum(), '\n')
sumdata.loc['합'] = sumdata.sum()
print('\n', sumdata, '\n')