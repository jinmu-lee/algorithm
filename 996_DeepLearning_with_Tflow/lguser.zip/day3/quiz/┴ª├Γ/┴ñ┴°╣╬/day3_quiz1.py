import pandas as pd
import numpy as np
import json

df1 = pd.DataFrame(np.arange(36).reshape((6,6)))
                   # index = pd.Index(['1','2','3','4','5','6'], name='num'),
                   # columns = pd.Index(['a','b','d','c','a','e'], name = 'al'))
df2 = pd.DataFrame(np.arange(36).reshape((6,6)))
                   # index = pd.Index(['1','2','6','4','5',], name='num'),
                   # columns = pd.Index(['a','b','d','c','a'], name = 'al'))
print('\n1', df1, '\n')
print('\n2', df2, '\n')

print('\nResult', pd.merge(df1, df2),'\n')