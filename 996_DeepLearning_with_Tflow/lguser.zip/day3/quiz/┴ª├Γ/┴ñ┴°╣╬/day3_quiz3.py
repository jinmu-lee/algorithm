import pandas as pd
import numpy as np

a_df_score2 = pd.DataFrame({'반':['a','a','a','a','a','b','b','b','b','b'],
                          '번호': [1, 2, 3, 4, 5, 1, 2, 3, 4, 5],
                          '국어': [1, 2, 3, 4, 5, 1, 2, 3, 4, 5],
                          '영어': [1, 2, 3, 4, 5, 1, 2, 3, 4, 5],
                          '수학': [1, 2, 3, 4, 5, 1, 2, 3, 4, 5]},
                        columns=['반', '번호', '국어', '영어', '수학'])
print('\n', a_df_score2, '\n')

b_df_score2 = a_df_score2.set_index(['반','번호'])
print('\n', b_df_score2, '\n')

b_df_score2['평균'] = b_df_score2[['국어', '영어', '수학']].mean(axis=1)
c_df_score2 = b_df_score2
print('\n', c_df_score2, '\n')

d_df_score2 = c_df_score2.unstack('번호')
print('\n', d_df_score2, '\n')
d_df_score2 = d_df_score2.set_index(['국어', '영어', '수학'])
print('\n', d_df_score2, '\n')