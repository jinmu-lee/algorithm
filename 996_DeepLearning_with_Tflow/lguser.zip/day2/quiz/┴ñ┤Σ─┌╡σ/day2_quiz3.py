import numpy as np


a = np.arange(30).reshape(5,6)
print(a,'\n')

#a
print(a.max(),'\n')

#b
print(a.sum(axis=1),'\n')

#c
print(a.mean(axis=0),'\n')

#d
print(a[np.argsort(a[:,0])],'\n')

#e
print(a[:,np.argsort(a[1,:])],'\n')