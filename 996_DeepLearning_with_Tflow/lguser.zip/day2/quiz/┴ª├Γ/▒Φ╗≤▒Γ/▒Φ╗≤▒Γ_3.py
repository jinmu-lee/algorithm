import numpy as np

np.random.seed(12345)
arr = np.random.randn(5, 6)

print('전체의 최대값: ', arr.max())
print('각 행의 합: ', arr.sum(axis=1))
print('각 열의 평균: ', arr.mean(axis=0))
print('첫번째 열 값으로 모든 행을 정렬:')
print(arr[arr[:,0].argsort(), :])
print('두번째 행 값으로 모든 열을 정렬:')
print(arr[:, arr[1,:].argsort()])
