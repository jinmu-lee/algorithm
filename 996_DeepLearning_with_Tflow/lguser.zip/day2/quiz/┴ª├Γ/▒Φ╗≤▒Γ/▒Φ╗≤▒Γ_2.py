import numpy as np

def getArrayFromFile(filename):
    infile = open(filename, 'r')
    desiredList = np.array([line.rstrip().split(',') for line in infile])
    infile.close()
    return desiredList

if __name__ == '__main__':
    rowArray = getArrayFromFile('Justices.txt')
    president = input("Enter the name of a president: ")
    selectArray = np.array([p for p in rowArray if president == p[2]])
    year = []
    for s in selectArray:
        year.append(np.int(s[4]) - (np.int(s[5]) if np.int(s[5]) else 2015))
    print("Justice Appointed:")
    for s in selectArray[np.array(year).argsort(), :]:
        print("        " + s[0] + " " + s[1])