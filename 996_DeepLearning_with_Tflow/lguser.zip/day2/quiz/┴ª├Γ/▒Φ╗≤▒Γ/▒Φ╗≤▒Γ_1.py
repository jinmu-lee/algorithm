import numpy as np

def getArrayFromFile(filename):
    infile = open(filename, 'r')
    desiredList = np.array([line.rstrip() for line in infile])
    infile.close()
    return desiredList

def removeAddColor(base, remove, add):
    return np.union1d(np.setdiff1d(base, remove), add)

def createSortedFile(listName, fileName):
    listName.sort()
    for i in range(len(listName)):
        listName[i] = listName[i] + "\n"
    outfile = open(fileName, 'w')
    outfile.writelines(listName)
    outfile.close()

if __name__ == '__main__':
    preArray = getArrayFromFile('Pre1990.txt')
    retArray = getArrayFromFile('Retired.txt')
    addArray = getArrayFromFile('Added.txt')
    finalArray = removeAddColor(preArray, retArray, addArray)
    createSortedFile(finalArray, 'final.txt')