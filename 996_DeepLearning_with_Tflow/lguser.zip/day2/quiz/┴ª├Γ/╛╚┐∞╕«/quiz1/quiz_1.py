
def getListFromFile(fileName):
    infile = open(fileName, 'r')
    returnList = [line.rstrip() for line in infile]
    infile.close()
    return returnList

def createNewFile(listName, oldFileName, newFilenName):
    infile = open(oldFileName, 'r')
    outfile = open(newFilenName, 'w')

    for person in listName:
        outfile.write(person+'\n')
    infile.close()
    outfile.close()

def deleteNewFile(listName, oldFileName, newFilenName):
    infile = open(oldFileName, 'r')
    outfile = open(newFilenName, 'w')
    for person in infile:
        if person.strip() not in listName:
            outfile.write(person)
    infile.close()
    outfile.close()


retire_list = getListFromFile('Retired.txt')
add_list = getListFromFile('Added.txt')

deleteNewFile(retire_list, 'Pre1990.txt', 'temp_1990.txt' )
createNewFile(add_list, 'temp_1990.txt', '1990.txt')