import numpy as np

init_arr = np.random.randn(30)
arr = init_arr.reshape(5,6)

print('a. max:\n',arr.max())
print('b. sum -axis 1:\n', arr.sum(axis=1))
print('c. mean - axis 0 :\n', arr.mean(axis=0))



print('d. argsort:\n', arr[arr[:,0].argsort()])

print('e. argsort:\n', arr[:, arr[1].argsort()])

#print(arr[0].argsort()) #열
#print(arr[:,0].argsort())  #행