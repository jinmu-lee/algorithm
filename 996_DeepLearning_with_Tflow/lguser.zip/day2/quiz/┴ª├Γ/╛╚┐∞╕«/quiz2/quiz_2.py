
import numpy as np
p_name = input('Enter the name of a president:')

infile = open('Justices.txt','r')
#firstList = np.array(line.rstrip() for line in infile)
firstList = [line.rstrip()+'\n' for line in infile] # 파일에서 읽어서 list형태로 정리
secondList = []
for i in range(len(firstList)):
    secondList.append(firstList[i].split(','))
infile.close()
p_name_set = {line[2] for line in secondList}

for i in range(len(secondList)):
    if p_name == secondList[i][2]:
        print(secondList[i][0]+' '+secondList[i][1])

