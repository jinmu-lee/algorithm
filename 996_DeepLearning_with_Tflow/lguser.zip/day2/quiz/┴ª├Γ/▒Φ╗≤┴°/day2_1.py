def readSetData(file):
    infile = open(file, 'r')
    set = {line for line in infile}
    return set

def createTotalCrayon(list):
    outfile = open('TotalCrayon.txt', 'w')
    outfile.writelines(list)
    outfile.close()

PreSet = readSetData('Pre1990.txt')
RetSet = readSetData('Retired.txt')
AddSet = readSetData('Added.txt')

diffColor = PreSet.difference(RetSet)
TotalColor = diffColor.union(AddSet)
list1 = list(TotalColor)
list1.sort()
createTotalCrayon(list1)

