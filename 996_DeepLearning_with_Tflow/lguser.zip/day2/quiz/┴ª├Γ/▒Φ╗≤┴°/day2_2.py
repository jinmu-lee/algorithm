def readData(file, name):
    infile = open(file, 'r')
    # Samuel,Alito,George W. Bush,NJ,2006,0
    list1 = [line for line in infile if line.split(',')[2] == name]
    infile.close()
    return list1


def checkYear(list1):
    for list in list1:
        list2 = list.split(',')
        if list2[5] == 0:
            list2[5] = 2015

name = input("Enter the name of a president:")
list1 = readData('Justices.txt', name)
#list2 = checkYear(list1)
list1.sort()

if (len(list1) > 0):
    print('Justice Appointed:')
    for i in range(len(list1)) :
        list1[i] = list1[i].split(',')
        print(' ' + list1[i][0] + ' ' + list1[i][1])
else :
    print('Not exist matched president!!!')