import numpy as np
np.random.seed(123456)

arr = np.arange(30).reshape(5,6)
print('\n초기값 : \n',arr)
print('\n최대값 : ',np.max(arr))
print('\n각행의 합 : ',arr.sum(axis=1))
print('\n각열의 평균 : ',arr.mean(axis=0))
print('\n첫 번째 열 값으로 모든 행으로 정렬 : \n', arr[arr[:, 0].argsort()])
print('\n두 번째 행 값으로 모든 열을 정렬 : \n', arr[:, arr[1:].argsort()])