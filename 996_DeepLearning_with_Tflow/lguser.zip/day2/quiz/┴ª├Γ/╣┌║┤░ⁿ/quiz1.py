import numpy as np

with open("Pre1990.txt") as pre1990:
    pre1990_color = np.array([color.strip() for color in pre1990])
with open("Retired.txt") as retired:
    retired_color = np.array([color.strip() for color in retired])
with open("Added.txt") as added:
    added_color = np.array([color.strip() for color in added])

result = np.union1d(np.setdiff1d(pre1990_color, retired_color), added_color)
result.sort()
with open("quiz1_result.txt", "w") as result_file:
    result_file.write("\n".join(result))

