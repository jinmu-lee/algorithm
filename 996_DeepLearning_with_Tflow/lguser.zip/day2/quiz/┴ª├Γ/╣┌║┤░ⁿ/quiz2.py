import numpy as np
with open('justices.txt') as justices_file:
    justice = np.array([x.strip().split(',') for x in justices_file])

president = input("Enter the name of a president:")
result = [" ".join(x) for x in justice[justice[:, 2] == president][:, :2]]

print("Justice Appointed:")
print("\n".join(result))

