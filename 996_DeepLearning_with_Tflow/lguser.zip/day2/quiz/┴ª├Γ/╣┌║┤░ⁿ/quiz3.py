import numpy as np
np.random.seed(12345)
matrix = np.random.randint(0, 100, 30).reshape(5, 6)
print(matrix)
print(f"전체의 최대값 : {matrix.max()}")
print(f"각 행의 합: {matrix.sum(axis=1)}")
print(f"각 열의 평균: {matrix.mean(axis=0)}")

print("첫번째 열 값으로 모든 행을 정렬")
key = matrix[:, 0]
indexer = key.argsort()
print(matrix[indexer])
print()
print("두번째 행 값으로 모든 열을 정렬")
key = matrix[1, :]
indexer = key.argsort()
print(matrix[:, indexer])