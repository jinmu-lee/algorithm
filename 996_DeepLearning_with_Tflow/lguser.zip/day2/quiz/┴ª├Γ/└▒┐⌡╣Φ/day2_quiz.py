import  numpy as np
'''
1.1990년 초에 크레욜라 크레용은 72개의 색상(Pre1990.txt)을 갖고 있었다. 1990년대
8색상(Retired.txt)이 빠지게 되었고 56개의 새로운 색상(Added.txt)이 추가되었다.
지난 1990년대 120개의 크레용 색상을 알파벳 순서로 나열한 텍스트 파일을 생성하는
프로그램을 작성하라.

'''
infile = open('Pre1990.txt', 'r')
Pre = {line.rstrip() + '\n' for line in infile}
infile.close()
infile = open('Retired.txt', 'r')
Retired = {line.rstrip() + '\n' for line in infile}
infile.close()
infile = open('Added.txt', 'r')
Added = {line.rstrip() + '\n' for line in infile}
infile.close()
outfile = open('result.txt','w')
temp = Pre.difference(Retired)
temp = temp.union(Added)
result_list = list(temp)
result_list.sort()
outfile.writelines(result_list)
outfile.close()
'''
2.Justices.txt를 참고하라.(이름, 성, 임명한 대통령, 임명 당시 재직한 주, 임명 연도, 
			   대법원을 사임한 연도)
대통령의 이름을 입력 받은 후 해당 대통령이 임명한 대법관을 표시하는 프로그램을 작성하라. 
대법관은 해당 법원에서 근무한 기간에 의해 내림 차순으로 정렬되어야 한다.
(대법원 사임 연도가 0인 경우 2015년으로 값을 대체한 후에 계산한다.)

ex>
	Enter the name of a president:George W. Bush
	Justice Appointed:
		John Roberts
		Smuel Alito


'''
infile = open('Justices.txt', 'r')
justice = [line.rstrip().split(',') for line in infile]
aData = np.array(justice)
values = aData[:,5]
result = np.where(values == '0','2015',values)
indexer = result.argsort()
aData = aData[indexer]
infile.close()
print('Enter the name of a president:',end='')
in_text = input()
print('Justice Appointed:')
for iline in aData:
    if iline[2] == in_text:
        print(iline[0],iline[1])

'''
3. 5 X 6 형태의 데이터 행렬을 만들고 이 데이터에 대해 다음과 같은 값을 구한다.

  a. 전체의 최대 값
  b. 각 행의 합
  c. 각 열의 평균
  d. 첫 번째 열 값으로 모든 행으로 정렬
  e. 두 번째 행 값으로 모든 열을 정렬
'''
arr = np.random.randn(5,6)

print('\n',arr)
print('\n',arr.max())
print('\n',arr.cumsum(axis=1))
print('\n',arr.mean(axis=0))
indexer = arr[:,0].argsort()
arr1 = arr[indexer]
print('\n',arr1)
indexer = arr[1].argsort()
arr2 = arr[:,indexer]
print('\n',arr2)