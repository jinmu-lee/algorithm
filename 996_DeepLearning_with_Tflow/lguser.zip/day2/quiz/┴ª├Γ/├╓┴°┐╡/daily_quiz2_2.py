import numpy as np

def getListFromFile(fileName):
    infile = open(fileName, 'r')
    selectList = [line.rstrip().split(',') for line in infile]
    infile.close()
    return selectList

openlist = getListFromFile('Justices.txt')

for i in openlist:
    if i[5] == '0':
        i[5] = '2015'
    i.append(int(i[5]) - int(i[4]))

presName = input('Enter the name of a president: ')
newlist = []
for i in openlist:
    if i[2] == presName:
        newlist.append(i)
#arr = np.array(newlist)
print('Justice Appointed:', '\n')
for i in newlist:
    print(i[0], ' ', i[1])

