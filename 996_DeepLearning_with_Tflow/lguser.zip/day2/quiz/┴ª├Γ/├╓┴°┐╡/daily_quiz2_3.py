import numpy as np

arr = np.random.randn(5,6)

print(arr, '\n')
print('max : ', arr.max(), '\n')
print('Sum of each row:', arr.sum(axis=0), '\n')
print('Mean of each column:', arr.mean(axis=1), '\n')
