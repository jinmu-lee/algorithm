import numpy as np

def getArrayFromFile(fileName):
    infile = open(fileName, 'r')
    selectList = [line.rstrip() for line in infile]
    infile.close()
    arr = np.array(selectList)
    return arr

def createSortedFile(listName, fileName):
    listName.sort()
    for i in range(len(listName)):
        listName[i] = listName[i] + "\n"
    outfile = open(fileName, 'w')
    outfile.writelines(listName)
    outfile.close()

pre1990Arr = getArrayFromFile("Pre1990.txt")
retiredArr = getArrayFromFile("Retired.txt")
addedArr = getArrayFromFile("Added.txt")

new1990Arr = np.union1d(np.setdiff1d(pre1990Arr, retiredArr), addedArr)

createSortedFile(new1990Arr, "new1990.txt")




