

import numpy as np

infile = open('justices.txt', 'r')
data = {line.rstrip() for line in infile}
infile.close()
justices=np.array(infile)



print(justices)