import numpy as np

arr=np.random.randn(5,5)


#a.전체의 최대값

print('\n', arr.max())

#b.각 행의 합
print('\n', arr.sum(axis=1))

#c.각 열의 평균
print('\n', arr.mean(axis=0))

#d.첫번째 열 값으로 정렬
print('\n',arr[np.argsort(arr[:,0])])

#e. 두번째 행 값으로 정렬
print('\n',arr[:,np.argsort(arr[1,:])])


