import numpy as np

#values = np.arange(30).reshape(5,6)
values = np.random.randn(5,6)
print(values)

print('\nmaximum : ')
print(np.max(values))

print('\n각행의 합 : ')
print(values.sum(axis=1))

print('\n각열의 평균 : ')
print(values.mean(axis=0))

print('\n첫번째 열값으로 모든 열을 정렬 : ')
print("==================================")
transValues = values.T
first_row = transValues[0]
indexer = first_row.argsort()
sortedvlues = transValues[:, indexer]
retransValues = sortedvlues.T
print(retransValues)

print('\n두번째 행값으로 모든 열을 정렬 : ')
print("==================================")
second_row = values[1]
indexer = second_row.argsort()
print(values[:, indexer])
