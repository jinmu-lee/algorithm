import numpy as np

def getListFromFile(fileName):
    infile = open(fileName, 'r')
    desiredList = [line.rstrip() for line in infile]
    infile.close()
    return desiredList

def createSortedFile(listName, fileName):
    listName.sort()
    for i in range(len(listName)):
        listName[i]=listName[i] + "\n"
    outfile = open(fileName, 'w')
    outfile.writelines(listName)
    outfile.close()

justicesList = getListFromFile("Justices.txt")
newJusticesList = []
for row in justicesList:
    newJusticesList.append(row.split(','))

newList = []
for row in newJusticesList:
    if row[2] == 'George W. Bush':
        newList.append(row)
print(newList)


....