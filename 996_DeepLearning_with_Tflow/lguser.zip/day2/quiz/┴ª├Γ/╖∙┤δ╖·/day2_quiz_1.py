import numpy as np

def getListFromFile(fileName):
    infile = open(fileName, 'r')
    desiredList = [line.rstrip() for line in infile]
    infile.close()
    return desiredList

def createSortedFile(listName, fileName):
    listName.sort()
    for i in range(len(listName)):
        listName[i]=listName[i] + "\n"
    outfile = open(fileName, 'w')
    outfile.writelines(listName)
    outfile.close()


pre1990List = getListFromFile("Pre1990.txt")
retiredList = getListFromFile("Retired.txt")
addedList = getListFromFile("Added.txt")

pre1990 = np.array(pre1990List)
retired = np.array(retiredList)
added = np.array(addedList)

setdiffcolor = np.setdiff1d(pre1990, retired)
unioncolor = np.union1d(setdiffcolor, added)

createSortedFile(unioncolor, "CurrColor.txt")
