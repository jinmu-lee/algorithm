import numpy as np

def getListFromFile(fileName):

    infile = open(fileName,'r')
    desiredList=[line.rstrip() for line in infile]
    infile.close()
    return desiredList

justices = getListFromFile('Justices.txt')

president = input("Enter the name of a president : ")

answer = []

for line in justices:
    list = line.split(',')

    if list[2] == president:
        answer.append(list)

answer=np.array(answer)
answer[answer=='0']='2015'

cal = np.arange(len(answer))
for i in range(len(answer)):
    cal[i]= int(answer[i][5])-int(answer[i][4])

print(cal)
print('******')
print(answer[cal])