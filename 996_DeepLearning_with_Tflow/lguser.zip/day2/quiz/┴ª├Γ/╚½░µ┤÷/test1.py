
def getListFromFile(fileName):

    infile = open(fileName,'r')
    desiredList=[line.rstrip() for line in infile]
    infile.close()
    return desiredList

def createSortedFile(listName, fileName):
    listName.sort()
    for i in range(len(listName)):
        listName[i] = listName[i]+'\n'
    outfile=open(fileName,'w')
    outfile.writelines(listName)
    outfile.close()

infile = open('Pre1990.txt','r')
Pre1990={line.rstrip()+'\n' for line in infile}
infile.close()

infile = open('Retired.txt','r')
Retired={line.rstrip()+'\n' for line in infile}
infile.close()

infile = open('Added.txt','r')
Added={line.rstrip()+'\n' for line in infile}
infile.close()

finalList = Pre1990.difference(Retired).union(Added)

outfile = open('Temp.txt','w')
outfile.writelines(finalList)
outfile.close()

finalList = getListFromFile('Temp.txt')
createSortedFile(finalList, 'New.txt')






