import numpy as np

np.random.seed(12345)
arr=np.random.randn(5,6)

print(arr)
print(arr.max())
print(arr.sum(axis=1))
print(arr.sum(axis=0))

print(arr[:,arr[0].argsort()])
print(arr[:,arr[0].argsort()])