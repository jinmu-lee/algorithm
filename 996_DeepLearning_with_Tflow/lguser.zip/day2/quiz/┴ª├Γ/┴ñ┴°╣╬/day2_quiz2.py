# 2.Justices.txt를 참고하라.(이름, 성, 임명한 대통령, 임명 당시 재직한 주, 임명 연도,
# 			   대법원을 사임한 연도)
# 대통령의 이름을 입력 받은 후 해당 대통령이 임명한 대법관을 표시하는 프로그램을 작성하라.
# 대법관은 해당 법원에서 근무한 기간에 의해 내림 차순으로 정렬되어야 한다.
# (대법원 사임 연도가 0인 경우 2015년으로 값을 대체한 후에 계산한다.)
#
# ex>
# 	Enter the name of a president:George W. Bush
# 	Justice Appointed:
# 		John Roberts
# 		Smuel Alito
infile = open('Justices.txt', 'r')
rawList = [line.rstrip().replace(',0',',2015').split(',') for line in infile]
#print(rawList)

pre = input('Enter the name of a president:')
findList = [line for line in rawList if pre == line[2]]
#print(findList)

for line in findList:
    line.insert(0, int(line[5])-int(line[4]))
#print(findList)

findList.sort(reverse=True)
#print(findList)

print('Justice Appointed:')
for line in findList:
    print('\n{} {}'.format(line[1], line[2]))
