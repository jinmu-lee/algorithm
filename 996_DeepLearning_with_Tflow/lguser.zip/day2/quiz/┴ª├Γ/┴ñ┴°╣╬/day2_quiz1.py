# 1.1990년 초에 크레욜라 크레용은 72개의 색상(Pre1990.txt)을 갖고 있었다. 1990년대
# 8색상(Retired.txt)이 빠지게 되었고 56개의 새로운 색상(Added.txt)이 추가되었다.
# 지난 1990년대 119개의 크레용 색상을 알파벳 순서로 나열한 텍스트 파일을 생성하는
# 프로그램을 작성하라.


infile = open('Pre1990.txt', 'r')
Pre1990Set = {line.rstrip() + '\n' for line in infile}

infile = open('Retired.txt', 'r')
RetiredSet = {line.rstrip() + '\n' for line in infile}

infile = open('Added.txt', 'r')
AddedSet = {line.rstrip() + '\n' for line in infile}

outfile = open('Quiz1.txt', 'w')
outfile.writelines(sorted(Pre1990Set.difference(RetiredSet).union(AddedSet)))
outfile.close()