# 3. 5 X 6 형태의 데이터 행렬을 만들고 이 데이터에 대해 다음과 같은 값을 구한다.
#
#   a. 전체의 최대 값
#   b. 각 행의 합
#   c. 각 열의 평균
#   d. 첫 번째 열 값으로 모든 행으로 정렬
#   e. 두 번째 행 값으로 모든 열을 정렬


import numpy as np

arr = np.random.randn(5,6)
#print(arr)

#   a. 전체의 최대 값
print(arr.max(), '\n')

#   b. 각 행의 합
print(arr.sum(axis=1), '\n')

#   c. 각 열의 평균
print(arr.mean(axis=0), '\n')

#   d. 첫 번째 열 값으로 모든 행으로 정렬
print(arr, '\n')
arr = arr.T
arr = arr[:, arr[0].argsort()]
arr = arr.T
print(arr, '\n')

#   e. 두 번째 행 값으로 모든 열을 정렬
print(arr[:, arr[1].argsort()], '\n')