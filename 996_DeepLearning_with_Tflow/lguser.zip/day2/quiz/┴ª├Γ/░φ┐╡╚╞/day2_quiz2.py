#Quiz 2-2:
import numpy as np

jus_DataSet = []
jus_Result = []
line_cnt = 0

with open('Justices.txt','r') as jus_file:
    while True:
        data = jus_file.readline()
        if not data : break
        data = data.strip()
        jus_DataSet.append(data.split(','))
        line_cnt += 1
    jus_DataSet = np.array(jus_DataSet).reshape(line_cnt, 6)


def President_input():
    Pres_name = input("Enter the name of president: ")
    jus_Result = jus_DataSet[(jus_DataSet[:,2] == Pres_name),:]

    jus_Result[jus_Result[:,5]=='0',5] = '2015'

    jus_Result = jus_Result[jus_Result[:,5].argsort(), :]

    with open('Quiz2.txt','w') as Q2_file:
        print("Justice Appointed:")
        for r in jus_Result:
            print("\t{0} {1}".format(r[0],r[1]))
            Q2_file.write("{0} {1}\n".format(r[0],r[1]))
President_input()