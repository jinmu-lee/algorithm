#Day2
import numpy as np

#Quiz 2-1:
Pre_dataSet = []
Ret_dataSet = []
Add_dataSet = []
Res_dataSet = []

with open('Pre1990.txt','r') as pre_file:
    while True:
        data = pre_file.readline()
        if not data : break
        Pre_dataSet.append(data)

with open('Retired.txt','r') as ret_file:
    while True:
        data = ret_file.readline()
        if not data : break
        Ret_dataSet.append(data)

with open('Added.txt','r') as add_file:
    while True:
        data = add_file.readline()
        if not data : break
        Add_dataSet.append(data)

with open('Quiz1.txt', 'w') as Q1_file:
    Res_dataSet = np.setdiff1d(Pre_dataSet, Ret_dataSet)
    Res_dataSet = np.union1d(Res_dataSet, Add_dataSet)

    Res_dataSet.sort()

    for data in Res_dataSet:
        Q1_file.writelines(data)