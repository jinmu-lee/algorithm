#Quiz 2-3:
import numpy as np

np.random.seed(12345)
res_str = []

arr = np.random.randint(-100, 100, 30, 'i').reshape(5,6)
max = arr.max()
sum_row = arr.sum(axis=0)
mean_col = arr.mean(axis=1)

arr2 = arr[arr[:,0].argsort(), :]
arr3 = arr[:,arr[1,:].argsort()]

res_str.append("a. {}".format(max))
res_str.append("b. {}".format(sum_row))
res_str.append("c. {}".format(mean_col))
res_str.append("d. \n{}".format(arr2))
res_str.append("e. \n{}".format(arr3))
print("a. {}".format(max))
print("b. {}".format(sum_row))
print("c. {}".format(mean_col))
print("d. \n{}".format(arr2))
print("e. \n{}".format(arr3))

with open('Quiz3.txt', 'w') as Q3_file:
    for a in res_str:
        Q3_file.writelines(a+'\n')