import numpy as np

arr = np.random.randn(5,6)
print(arr, '\n')

print('\n 전체의 최대 값: ', arr.max())
print('\n 각 행의 합', arr.sum(axis=1))
print('\n 각 열의 평균', arr.mean(axis=0))

print('\n 첫 번째 열 값으로 모든 행으로 정렬')
print(arr[arr[:,0].argsort()], '\n')
print('\n 두 번째 행 값으로 모든 열을 정렬')
print(arr [:, arr[1].argsort()], '\n')

