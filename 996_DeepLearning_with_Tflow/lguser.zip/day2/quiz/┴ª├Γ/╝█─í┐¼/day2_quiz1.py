def getlistFromFile(file):
    infile = open(file, 'r')
    list = {line.rstrip() + '\n' for line in infile}
    infile.close()
    return list

def createFile(list1, list2, list3, file):
    allList = list1.difference(list2)
    allList = list1.union(list3)

    outfile = open(file, 'w')
    outfile.writelines(sorted(allList))
    outfile.close()

preList = getlistFromFile('Pre1990.txt')
retireList = getlistFromFile('Retired.txt')
addList = getlistFromFile('Added.txt')
createFile(preList, retireList, addList, 'FinalList.txt')

