import numpy as np

def getlistFromFile(file, name):
    infile = open(file, 'r')
    name_list = [line for line in infile if line.split(',')[2] == name]
    infile.close()
    return name_list

def sortlist(list):
    for i in range(len(list)):
        list[i] = list[i].split(',')
        list[i][4] = int(list[i][4])
        list[i][5] = int(list[i][5])

    for line in list:
        if line[5] == 0:
            line[5] = 2015
    print_info(list)

def print_info(list):
    list.sort(key=lambda list: list[5] - list[4], reverse=True)
    print("Justices Appointed : ")
    for justice in list:
        print(justice[0] + "," + justice[1])

name = input("Enter the name of a president ")
justiceList = getlistFromFile('Justices.txt', name)
sortlist(justiceList)

