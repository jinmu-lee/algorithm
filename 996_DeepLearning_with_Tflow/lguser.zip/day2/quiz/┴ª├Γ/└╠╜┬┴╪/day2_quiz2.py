def getListFromFile(fileName):
    infile = open(fileName, 'r')
    desiredList = [line.rstrip() for line in infile]
    infile.close()

    return desiredList

List = getListFromFile("Justices.txt")

while True:
    president_name = input('Enter the name of a president: ')
    for item in List:
        split_list = item.split(',')
        if president_name == split_list[2]:
            print_list =[]
            print_list.append(split_list)


    print('Justice Appointed : \n')

    for item in print_list:
        dic = {}
        if item[5] == 0:
            item[5] = 2015
        year1 = item[5] - item[4]



