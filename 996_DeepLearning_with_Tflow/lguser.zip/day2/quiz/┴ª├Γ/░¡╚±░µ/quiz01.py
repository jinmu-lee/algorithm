import numpy as np

def getListFromFile(fileName):
    infile = open(fileName, 'r')
    desiredList = [line.rstrip() for line in infile]
    infile.close()
    return desiredList

def updateColor(preList, retList, addList):
    preArr = np.array(preList)
    retArr = np.array(retList)
    addArr = np.array(addList)
    tempArr = np.unique(np.union1d(np.setdiff1d(preArr, retArr), addArr))
    tempArr.sort()
    return tempArr

preList = getListFromFile("Pre1990.txt")
retList = getListFromFile("Retired.txt")
addList = getListFromFile("Added.txt")

result = updateColor(preList, retList, addList)
resultFile = open("Result.txt", "w")
resultList = []
for color in result:
    resultList.append(color + '\n')
resultFile.writelines(resultList)
resultFile.close()
