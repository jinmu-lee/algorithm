import numpy as np

arr = np.random.randint(0, 10, 30).reshape(5,6)
np.random.shuffle(arr)

print(arr)

print("\n", "MAX : {0}".format(arr.max()))
print("Row Sum: {0}".format(arr.sum(axis=1)))
print("Col Mean: {0}".format(arr.mean(axis=0)))
print("\n", "Sort by Row1: ")
print(arr[:, arr[0].argsort()])
print("\n", "Sort by Col1: ")
arrT = arr.T
print(arrT[:, arrT[0].argsort()].T)