import numpy as np

class Justice:
    def __init__(self, info):
        self.name = info[0] + " " + info[1]
        self.president = info[2]
        self.state = info[3]
        self.start = int(info[4])
        if info[5] == "0":
            self.end = 2015
        else:
            self.end = int(info[5])
        self.period = int(self.end - self.start)
    def test(self):
        print("{0}, {1}. {2}".format(self.name, self.president, self.period))

def getListFromFile(fileName):
    infile = open(fileName, 'r')
    desiredList = [line.rstrip() for line in infile]
    infile.close()
    return desiredList

lines = getListFromFile("Justices.txt")
justList = []
for line in lines:
    info = line.split(",")
    just = Justice(info)
    justList.append(just)

nameList = []
presidentList = []
periodList = []

inputName = input("Enter the name of a president: ")

for just in justList:
    if (just.president == inputName):
        nameList.append(just.name)
        presidentList.append(just.president)
        periodList.append(just.period)

nameArr = np.array(nameList)
presidentArr = np.array(presidentList)
periodArr = np.array(periodList)
arr = np.c_[np.c_[nameArr, presidentArr], periodArr]
arrt =  arr.T
print(arrt[:1, arrt[2].argsort()].T)




