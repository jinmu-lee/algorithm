import numpy as np
np.random.seed(0)
arr=np.random.randn(5,6)

#print(arr)
print('전체의 최대 값\n', arr.max())
print('\n각 행의 합\n', arr.sum(axis=1))
print('\n각 열의 평균\n', arr.mean(axis=0))

index=arr[:,0].argsort()
#print(index)
print('\n첫 번째 열 값으로 모든 행 정렬\n', arr[index,:])

index=arr[1,:].argsort()
#print(index)
print('\n두 번째 행 값으로 모든 열 정렬\n', arr[:,index])