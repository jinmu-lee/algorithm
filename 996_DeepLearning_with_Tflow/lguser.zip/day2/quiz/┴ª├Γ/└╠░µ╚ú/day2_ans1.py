f_pre = open('Pre1990.txt', 'r')
f_ret = open('Retired.txt', 'r')
f_add = open('Added.txt', 'r')
f_out = open('crayon_1990s.txt', 'w')

crayon_pre = set([crayon.rstrip() + '\n' for crayon in f_pre])
crayon_ret = set([crayon.rstrip() + '\n' for crayon in f_ret])
crayon_add = set([crayon.rstrip() + '\n' for crayon in f_add])

crayon_1990s = crayon_pre.difference(crayon_ret)
crayon_1990s = crayon_1990s.union(crayon_add)

f_out.writelines(sorted(crayon_1990s))

f_pre.close()
f_ret.close()
f_add.close()
f_out.close()
