import numpy as np
infile = open('Justices.txt', 'r')

buffer = [line for line in infile]

justices_list = []

for line in buffer :
    justice = line.rstrip().split(',')
    if justice[5] == '0' :
        justice[5] = '2015'
    justice.append(int(justice[5]) - int(justice[4]))
    justices_list.append(justice)

#print(justices_list)

name = input('Enter the name of a president : ')
print( 'Justice Appinted :')

for justice in justices_list :
    if name == justice[2] :
        print(justice[0], justice[1])
