

def getDataSetFromFile(fileName):
    with open(fileName, 'r') as file:
        datalist = {line.rstrip() for line in file}
    return datalist


def writeDataSetToFile(fileName, dataSet):
    with open(fileName, 'w') as file:
        file.writelines({line + "\n" for line in dataSet})


pre1990 = getDataSetFromFile('./data/Pre1990.txt');
retired = getDataSetFromFile('./data/Retired.txt');
added = getDataSetFromFile('./data/Added.txt');
writeDataSetToFile('./data/now1990.txt', pre1990.difference(retired).union(added))