import numpy as np


def getDataSetFromFile(fileName):
    with open(fileName, 'r') as file:
        datalist = [line.rstrip() for line in file]
    return datalist


justicsList = getDataSetFromFile('./data/Justices.txt')
president = input('Enter the name of a president:')
justices_split = [just.split(',') for just in justicsList if just.find(president) > 0]
justices_arr = np.array(justices_split)

indexer = [2015-int(i[4]) if i[5] == '0' else int(i[5])-int(i[4]) for i in justices_split]
indexer.sort()
indexer=indexer[::-1]

print('Justice Appointed:')
for j in justices_arr[np.argsort(indexer)]:
    print(j[0] + " " + j[1])
