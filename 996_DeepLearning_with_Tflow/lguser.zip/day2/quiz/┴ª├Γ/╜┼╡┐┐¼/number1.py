'''
1.1990년 초에 크레욜라 크레용은 72개의 색상(Pre1990.txt)을 갖고 있었다. 1990년대
8색상(Retired.txt)이 빠지게 되었고 56개의 새로운 색상(Added.txt)이 추가되었다.
지난 1990년대 119개의 크레용 색상을 알파벳 순서로 나열한 텍스트 파일을 생성하는
프로그램을 작성하라.
'''

import numpy as np

old_color = 'Pre1990.txt'
remove_color = 'Retired.txt'
new_color = 'Added.txt'
color_list = []
remove_color_list =[]
new_color_list = []

with open(old_color, 'r') as file:
    for line in file:
        color_list.append(line)
    color_list.sort()

with open(remove_color, 'r') as file:
    for line in file:
        remove_color_list.append(line)
    color_list.sort()

with open(new_color, 'r') as file:
    for line in file:
        new_color_list.append(line)
    color_list.sort()

diff_color = np.setdiff1d(color_list, remove_color_list)

result = np.union1d(diff_color, new_color_list)
result.sort()

with open('newColor.txt', 'w') as file:
    for line in result:
        file.write(line)

