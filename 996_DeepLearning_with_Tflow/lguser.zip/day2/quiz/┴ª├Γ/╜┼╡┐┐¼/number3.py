'''
3. 5 X 6 형태의 데이터 행렬을 만들고 이 데이터에 대해 다음과 같은 값을 구한다.

  a. 전체의 최대 값
  b. 각 행의 합
  c. 각 열의 평균
  d. 첫 번째 열 값으로 모든 행으로 정렬
  e. 두 번째 행 값으로 모든 열을 정렬
'''

import numpy as np

np.random.seed(12345)

arr = np.random.rand(5, 6)

print(arr)

print("\na. max value\n", arr.max())
print("\nb. sum of each row\n", arr.sum(axis=1))
print("\nc. average of each column\n", arr.mean(axis=0))

total = np.array(arr)
values = np.array([arr[0][0], arr[1][0], arr[2][0], arr[3][0], arr[4][0]])
indexer = values.argsort()

print("\nd. sort as first column value\n", total[indexer])

print("\ne. sort as second row value\n", arr[:, arr[1].argsort()])

