'''
2.Justices.txt를 참고하라.(이름, 성, 임명한 대통령, 임명 당시 재직한 주, 임명 연도,
			   대법원을 사임한 연도)
대통령의 이름을 입력 받은 후 해당 대통령이 임명한 대법관을 표시하는 프로그램을 작성하라.
대법관은 해당 법원에서 근무한 기간에 의해 내림 차순으로 정렬되어야 한다.
(대법원 사임 연도가 0인 경우 2015년으로 값을 대체한 후에 계산한다.)

ex>
	Enter the name of a president:George W. Bush
	Justice Appointed:
		John Roberts
		Smuel Alito
'''

import numpy as np

input_list = []

with open('Justices.txt', 'r') as file:
    input_list = [line[:-1] for line in file]

president_name = input("Enter the name of a president : ")
result = []

for line in input_list:
    tmp = line.split(',')
    if tmp[2] == president_name:
        result.append(tmp)


sort_result = np.array(result).reshape(len(result), 6)
year = []

for i in range(len(sort_result)):
    if sort_result[i][5] == '0':
        sort_result[i][5] = 2015
        year.append(2015 - int(sort_result[i][4]))
    else:
        year.append(int(sort_result[i][5]) - int(sort_result[i][4]))

year = np.array(year)
indexer = (-year).argsort()

sort_result = sort_result[indexer]

print("Justice Appointed : ")
for i in range(len(sort_result)):
    print(sort_result[i][0] + " " + sort_result[i][1])

