class Justice:
    def __init__(self, name1, name2, pres_name, years):
        self._name1 = name1
        self._name2 = name2
        self._pres_name = pres_name
        self._years = years

    def set_name1(self, name1):
        self._name1 = name1
    def get_name1(self):
        return self._name1
    def set_name2(self, name2):
        self._name2 = name2
    def get_name2(self):
        return self._name2
    def set_pres_name(self, pres_name):
        self._pres_name = pres_name
    def get_pres_name(self):
        return self._pres_name
    def set_years(self, years):
        self._years = years
    def get_years(self):
        return self._years


class Justice_List:
    def __init__(self, items=[]):
        self._items = items

    def addItemToList(self, item):
        self._items.append(item)

    def getItems(self):
        return self._items


def getListFromFile(fileName):
    infile = open(fileName, 'r')
    desiredList = [line.rstrip() for line in infile]
    infile.close()

    return desiredList

myJustice_list =Justice_List()


List = getListFromFile("Justices.txt")

while True:
    president_name = input('Enter the name of a president: ')
    for item in List:
        print(item)
        if president_name == item.__getitem__(2):
            print('b')
            print_list =[]
            print_list.append(item)
        else :
            print('a')
    print('Justice Appointed : \n')

