import numpy as np

arr = np.random.randn(5,6)

print(arr, '\n')
print('a.전체 최대의 값 : ', arr.max() )
print('b. 각 행의 합 : ', arr.sum(axis=1))

print('c. 각 열의 평균 : ', arr.sum(axis=0)/5)
arr.sort(axis=0)
print('d. 첫 번째 열 값으로 모든 행으로 정렬 : \n', arr)
arr.sort(axis=1)
print('e. 두 번째 행 값으로 모든 열을 정렬 : \n', arr)


