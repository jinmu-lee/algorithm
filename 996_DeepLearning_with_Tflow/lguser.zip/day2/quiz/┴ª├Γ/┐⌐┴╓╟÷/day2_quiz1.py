def getDicFromFile(fileName):
    infile = open(fileName, 'r')
    desiredDic = {line.rstrip() for line in infile}
    infile.close()
    return desiredDic


def createSortedFile(dicName, fileName):
    list = [line.rstrip() for line in dicName]
    list.sort()
    for i in range(len(list)):
        list[i] = list[i] + "\n"

    outfile = open(fileName, 'w')
    outfile.writelines(list)
    outfile.close()

color_Dic = getDicFromFile("Pre1990.txt")
retired_color_Dic = getDicFromFile("Retired.txt")
added_color_Dic = getDicFromFile("Added.txt")

temp_dic = {}
temp_dic = color_Dic.difference(retired_color_Dic)
temp_dic = temp_dic.union(added_color_Dic)

createSortedFile(temp_dic, "new_sorted_color.txt")