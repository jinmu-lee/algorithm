import numpy as np

values = np.array([5, 0, 1, 3, 2])
indexer = values.argsort()  #정렬된 인덱스 값 반환
print(indexer,'\n')
print(values[indexer],'\n')

arr = np.random.randn(3,5)
arr[0] = values
print(arr,'\n')
print(arr[:, arr[0].argsort()],'\n')

