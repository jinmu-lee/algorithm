import numpy as np

arr = np.arange(10)
print('\n',arr[5])
print('\n',arr[5:8])
arr[5:8] = 12
print('\n',arr)

arr_slice = arr[5:8].copy()
print('\n',arr_slice)

arr_slice[1] = 12345
print('\n',arr)

arr_slice[:] = 64
print('\n',arr)

aData = np.array([[1,2,3],[4,5,6]])
print(aData,'\n')
print(aData[1,2])
print(aData[0:2,0:1])
print(aData[0:2,:])