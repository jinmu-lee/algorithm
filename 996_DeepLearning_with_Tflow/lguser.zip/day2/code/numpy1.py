import numpy as np

data1 = [6, 7.5, 8, 0, 1]
arr1 = np.array(data1)
print(data1,'\n')
print(arr1,'\n')

data2 = [[1,2,3,4], [5,6,7,8]]
arr2 = np.array(data2)
print(arr2,'\n')

print(arr2.ndim,'\n')
print(arr2.shape,'\n')
print(arr2.dtype,'\n')

