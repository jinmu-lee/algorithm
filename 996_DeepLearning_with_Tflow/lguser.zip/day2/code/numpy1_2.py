import numpy as np

arr = np.array([1,2,3,4,5],dtype=np.int32)
print(arr.dtype, '\n')

float_arr = arr.astype(np.float32);
print(float_arr.dtype,'\n')

arr = np.array([3.7, -1.2, -2.6, 0.5, 12.9, 10.1])
print(arr,'\n')
intarr = arr.astype(np.int32)
print(intarr,'\n')

numeric_strings = np.array(['1.23', '-9.6', '42'], dtype=np.string_)
print(numeric_strings,'\n')
print(numeric_strings.astype(float))