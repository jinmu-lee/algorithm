import numpy as np
arr = np.random.randn(100)
print('\n',(arr > 0).sum(),'\n')

bools = np.array(([False, False, True, False]))
print(bools.any(),'\n')
print(bools.all(), '\n')

arr = np.random.randn(5,3)
print('\n',arr)

arr.sort(axis=1)
print('\n',arr)

arr.sort(axis=0)
print('\n',arr)
