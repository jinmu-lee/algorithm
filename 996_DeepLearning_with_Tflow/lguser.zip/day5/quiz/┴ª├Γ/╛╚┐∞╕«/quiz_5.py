import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#a 데이터셋을  data frame으로 읽어온다.
fec = pd.read_csv('winequality-both.csv')
#print(fec[:10])

# b.변수별 요약 통계 표시 (describe? value_count
print('***************************************')
print('***** B. 변수별 요약 통계 *****************')
print('***************************************')
for i in range(len(fec.keys())):
    print('<<',fec.keys()[i],'>>:')
    print(fec[fec.keys()[i]].describe(), '\n')


#c. 각 요소의 유일 값  value_count가 1인 항목
print('***************************************')
print('***** C. 각요소의 유일값 *****************')
print('***************************************')
items =['type', 'fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide',
        'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol', 'quality']

for i in range(len(items)):
    series_1 = fec[items[i]].value_counts()
    #print(series_1.index)
    series_1 = series_1[series_1.values == 1]
    #print(series_1.index)
    if len(series_1) is not 0:
        print('################################')
        print('index : ', items[i], '\n')
        print(series_1)


#각 요소의 빈도
print('***************************************')
print('***** D. 각요소의 빈도 *****************')
print('***************************************')
def print_percent(group, idx_list):
    itr = group.size()
    total_sum = itr.sum()
    for i in range(len(idx_list)):
        print(idx_list[i],' : ', round(((itr[idx_list[i]]) / (total_sum)),3))

for i in range(len(items)):
    print(items[i], ':')
    grouped = fec.groupby([items[i]])
    idx_list = grouped.size().keys()
    print_percent(grouped, idx_list)
    print('\n')


#와인 종류에 따른 기술 통계
print('***************************************')
print('***** E. 종류에 따른 기술 통계 *****************')
print('***************************************')
bins = np.array([1,2,4,6,8,10])
labels = pd.cut(fec.quality, bins)
grouped = fec.groupby(['type', labels])
print('\n',grouped.size().unstack(0),'\n')

#막대 그래프 출력, 비율.
quality_sums = grouped.quality.sum().unstack(0)
normed_sums = quality_sums.div(quality_sums.sum(axis=1), axis=0)
print('\n',normed_sums,'\n')
normed_sums.plot(kind='barh', stacked=False)
plt.show()


#상관계수
print('***************************************')
print('***** H. 상관계수 *****************')
print('***************************************')
print('\n', fec.corr(), '\n')