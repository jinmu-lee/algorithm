# 1. 와인 품질 데이터셋을 이용한다.
#  a. 데이터 셋을 DataFrame으로 읽어온다.
#  b. 변수별 요약 통계를 표시한다.
#  c. 각 요소의 유일 값을 찾아 출력한다.
#  d. 각 요소의 빈도를 계산하여 출력한다.
#  e. 와인 종류에 따른 기술 통계를 출력한다.
#  f.  와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다.
#     (이때 범례도 같이 출력한다. )
#  g. 와인 종류에 딸 품질의 차이를 검정하여 각 각을 출력한다.
#  h. 모든 변수 쌍 사이의 상관계수를 출력한다.

import pandas as pd
#a
print('a. 데이터 셋을 DataFrame으로 읽어온다.')
data = pd.read_csv('winequality-both.csv')
print(data, '\n')

#b
print('b. 변수별 요약 통계를 표시한다.')
print(data.info(), '\n')
#c, d
print('c, d. 각 요소의 유일 값, 빈도를 계산하여 출력한다.')
for c in data.columns:
    print(c, '(유일값): ', data[c].unique(),  '\n')
    print(c, '(빈도): ', data[c].value_counts(), '\n')

#e
print('e. 와인 종류에 따른 기술 통계를 출력한다.')
# red = data[data['type'] == 'red']
# print(red)

print('평균: \n', data.groupby(['type'], as_index=False).mean())
print('최대: \n', data.groupby(['type'], as_index=False).max())
print('최소: \n', data.groupby(['type'], as_index=False).min(), '\n')

#f
import matplotlib.pyplot as plt
by_type = data.pivot_table('fixed acidity', index='type', columns='quality', aggfunc='count').fillna(0)
by_type.plot(kind='bar')
plt.show()

#g
from scipy.stats import ttest_ind
print('g. 와인 종류에 딸 품질의 차이를 검정하여 각 각을 출력한다.')
print('t-test p-value: ', ttest_ind(by_type.loc['red'], by_type.loc['white'], equal_var=False).pvalue, '\n')

#h
print('h. 모든 변수 쌍 사이의 상관계수를 출력한다.')
print(data.corr(method ='pearson'))
