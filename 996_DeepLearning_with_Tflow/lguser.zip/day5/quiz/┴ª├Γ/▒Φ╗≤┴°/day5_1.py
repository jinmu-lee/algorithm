from datetime import datetime
import pandas as pd
import numpy as np
np.random.seed(12345)

#1. 와인 품질 데이터셋을 이용한다.

# a. 데이터 셋을 DataFrame으로 읽어온다.
windd = pd.read_csv('winequality-both.csv')
print('\n', windd, '\n')

# b. 변수별 요약 통계를 표시한다.
print('\n', windd.info(), '\n')
print('\n', windd.describe(), '\n')

# c. 각 요소의 유일 값을 찾아 출력한다.
columns = ['type',
           'fixed acidity',
           'volatile acidity',
           'citric acid',
           'residual sugar',
           'chlorides',
           'free sulfur dioxide',
           'total sulfur dioxide',
           'density',
           'pH',
           'sulphates',
           'alcohol',
           'quality'
           ]
for i in range(13):
    unique_data = windd[columns[i]].unique()
    print('\n유일 값 :', columns[i], '\n', unique_data, '\n')


# d. 각 요소의 빈도를 계산하여 출력한다.
for i in range(13):
    frequency = windd[columns[i]].value_counts()
    print('\n빈도 :', columns[i], '\n', frequency, '\n')

# e. 와인 종류에 따른 기술 통계를 출력한다.

# f. 와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다. (이때 범례도 같이 출력한다. )

# g. 와인 종류에 따른 품질의 차이를 검정하여 각 각을 출력한다.

# h. 모든 변수 쌍 사이의 상관계수를 출력한다.
print('\n', windd.corr(method='pearson'))