import pandas as pd
import matplotlib.pyplot as plt


wineData = pd.read_csv('./data/winequality-both.csv')

wineDataDf = pd.DataFrame(wineData)
print('a.데이터 셋을 DataFrame으로 읽어온다.')
print(wineDataDf[:2])

print()
print('b.변수별 요약 통계를 표시한다.')
print(wineDataDf.describe())

print()
print('c.각 요소의 유일 값을 찾아 출력한다.')
for list in wineDataDf.columns:
    print(wineDataDf[list].unique())

print()
print('d.각 요소의 빈도를 계산하여 출력한다.')
print(wineDataDf.count(axis=0))

print()
print('e.와인 종류에 따른 기술 통계를 출력한다. ')
by_type = wineData.pivot_table(index='type' , aggfunc='mean')
print(by_type)

print()
print('f.와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다.')
grouped = wineDataDf.groupby(['type', 'quality'])
print(grouped.quality.count().unstack(0))
grouped.quality.count().unstack(0).plot(kind='bar')
plt.show()

print()
print('g.와인 종류에 따른 품질의 차이를 검정하여 각 각을 출력한다.')
print(wineDataDf.groupby(['type', 'quality']).describe())

print()
print('h.모든 변수 쌍 사이의 상관계수를 출력한다.')
print(wineDataDf.corr())