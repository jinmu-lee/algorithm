import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

wq = pd.read_csv('winequality-both.csv')
db = pd.DataFrame(wq)
# a.데이터 셋을 DataFrame으로 읽어온다.
print('a. \n', db, '\n')
# b.변수별 요약 통계를 표시한다.
print('b. \n', db.info(), '\n')

# c, d (type만)
unique_type = wq.type.unique()
# c.각 요소의 유일 값을 찾아 출력한다.
print('c. \n', unique_type, '\n')
# d.각 요소의 빈도를 계산하여 출력한다.
print('d. \n', wq.type.value_counts(), '\n')

# c, d (각 요소)
for i in db.keys():
    # c.각 요소의 유일 값을 찾아 출력한다.
    print('c. \n', db[i].unique(), '\n')
    # d.각 요소의 빈도를 계산하여 출력한다.
    print('d. \n', db[i].value_counts(), '\n')

# e. 와인 종류에 따른 기술 통계를 출력한다.
db_wine = db.set_index(['type'])
grouped_e = db_wine.groupby(['type'])
print('e. \n', grouped_e.describe(), '\n')

#  f.  와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다.
#     (이때 범례도 같이 출력한다. )
bins = np.array([3,4,5,6,7,8,9])
labels = pd.cut(wq.quality, bins)
print('\n', labels, '\n')

grouped_f = wq.groupby(['type', labels])
print('f. \n', grouped_f.size(), '\n')
print('f. \n', grouped_f.size().unstack(0), '\n')

qlt_sums = grouped_f.quality.sum().unstack(0)
print('f. \n', qlt_sums, '\n')
qlt_sums.plot(kind='barh')
plt.show()

# nor_sums = qlt_sums.div(qlt_sums.sum(axis=1), axis=0)
# print('f. \n', nor_sums, '\n')
# nor_sums.plot(kind='barh', stacked=True)
# plt.show()

#  g. 와인 종류에 딸 품질의 차이를 검정하여 각 각을 출력한다.


#  h. 모든 변수 쌍 사이의 상관계수를 출력한다.
db_wine = db.set_index(['type'])
grouped_h = db.groupby(['type'])

corr_f = lambda x : x.corrwith(x['quality'])
print('h. \n', grouped_h.apply().apply(corr_f), '\n')