import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt
from datetime import datetime
import random


DataFrame=pd.read_csv('winequality-both.csv')

print(DataFrame[:3])

print(DataFrame.info())
print(DataFrame.columns)
print("----")

columns= DataFrame.columns
for i in columns :
    print(DataFrame[i].value_counts())
print('---------1')

print(DataFrame.drop_duplicates())
print('---------d')
#print(DataFrame.drop_duplicates()[:].value_counts())


pivot= DataFrame.pivot_table(index='type', columns='quality')
print(pivot)
