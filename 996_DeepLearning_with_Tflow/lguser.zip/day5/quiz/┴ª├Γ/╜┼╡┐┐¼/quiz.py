'''
1. 와인 품질 데이터셋을 이용한다.
 a. 데이터 셋을 DataFrame으로 읽어온다.
 b. 변수별 요약 통계를 표시한다.
 c. 각 요소의 유일 값을 찾아 출력한다.
 d. 각 요소의 빈도를 계산하여 출력한다.
 e. 와인 종류에 따른 기술 통계를 출력한다.
 f.  와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다.
    (이때 범례도 같이 출력한다. )
 g. 와인 종류에 딸 품질의 차이를 검정하여 각 각을 출력한다.
 h. 모든 변수 쌍 사이의 상관계수를 출력한다.

'''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# a. 데이터 셋을 DataFrame으로 읽어온다.
fec = pd.read_csv('winequality-both.csv')
db =  pd.DataFrame(fec)

# b. 변수별 요약 통계를 표시한다.
print('---------------------------------------------------')
print('\n', fec.info())
print('---------------------------------------------------')


# c. 각 요소의 유일 값을 찾아 출력한다.
print('---------------------------------------------------')
for column in fec.columns:
    unique = fec[column].unique()
    print('\n', unique)
print('---------------------------------------------------')


# d. 각 요소의 빈도를 계산하여 출력한다.
print('---------------------------------------------------')
for column in fec.columns:
    count = fec[column].value_counts()
    print('\ncolumn : ', column)
    print(count)
print('---------------------------------------------------')


# e. 와인 종류에 따른 기술 통계를 출력한다.
print('---------------------------------------------------')
print(fec.pivot_table(index='type'))
print('---------------------------------------------------')


# f. 와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다.
print('---------------------------------------------------')
plt.style.use('ggplot')

quality = db.groupby(['type', 'quality']).size()
print(quality)

quality.plot(kind='barh')
plt.show()
print('---------------------------------------------------')


# g. 와인 종류에 딸 품질의 차이를 검정하여 각 각을 출력한다.??





# h. 모든 변수 쌍 사이의 상관계수를 출력한다.