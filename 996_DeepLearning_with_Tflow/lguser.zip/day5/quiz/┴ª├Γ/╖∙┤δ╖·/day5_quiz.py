import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

print('\n\n\n=========================', 'a. 데이터 셋을 DataFrame으로 읽어온다.')
fec = pd.read_csv('winequality-both.csv')
print('\n', fec)

print('\n\n\n=========================', 'b. 변수별 요약 통계를 표시한다.')
print('\n', fec.describe())

print('\n\n\n=========================', 'c. 각 요소의 유일 값을 찾아 출력한다.')
unique_type = fec.type.unique()
print('\n', unique_type)

print('\n\n\n=========================', 'd. 각 요소의 빈도를 계산하여 출력한다.')
print('\n', fec.type.value_counts())

print('\n\n\n=========================', 'e. 와인 종류에 따른 기술 통계를 출력한다.')
fec_mrbo = fec[fec.type.isin(['red', 'white'])]
grouped = fec_mrbo.groupby(['type'])
print('\n', grouped.describe())

print('\n\n\n=========================', 'f.  와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다.(이때 범례도 같이 출력한다.)')



