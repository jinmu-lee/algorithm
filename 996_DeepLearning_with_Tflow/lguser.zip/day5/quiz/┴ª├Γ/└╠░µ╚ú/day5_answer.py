# 1. 와인 품질 데이터셋을 이용한다.
#
#  a. 데이터 셋을 DataFrame으로 읽어온다.
#
#  b. 변수별 요약 통계를 표시한다.
#
#  c. 각 요소의 유일 값을 찾아 출력한다.
#
#  d. 각 요소의 빈도를 계산하여 출력한다.
#
#  e. 와인 종류에 따른 기술 통계를 출력한다.
#
#  f.  와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다.
#     (이때 범례도 같이 출력한다. )
#
#  g. 와인 종류에 딸 품질의 차이를 검정하여 각 각을 출력한다.
#
#
#  h. 모든 변수 쌍 사이의 상관계수를 출력한다.

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#  a. 데이터 셋을 DataFrame으로 읽어온다.
wines = pd.read_csv('winequality-both.csv')


#  b. 변수별 요약 통계를 표시한다.
print(wines.info(), '\n')
print(wines.describe(), '\n')

#print(wines.loc[2345], '\n')


#  c. 각 요소의 유일 값을 찾아 출력한다.
for index in wines:
    print(wines[index].unique(),'\n')


#  d. 각 요소의 빈도를 계산하여 출력한다.
for index in wines:
    print(wines[index].value_counts(), '\n')


#  e. 와인 종류에 따른 기술 통계를 출력한다.
wines_type = wines.groupby('type')
print(wines_type.describe().unstack().unstack(2), '\n')


#  f.  와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다.
#     (이때 범례도 같이 출력한다. )
grouped = wines['quality'].groupby(wines['type']).value_counts().sort_index().unstack(0)
normed  = grouped.div(grouped.sum(axis=0), axis=1)

plt.style.use('ggplot')
normed.plot(kind='bar')
plt.title('Quality of Wines')
plt.xlabel('Quality Grade')
plt.ylabel('Distribution')
plt.legend()
plt.tight_layout()
plt.show()


#  g. 와인 종류에 따라 품질의 차이를 검정하여 각 각을 출력한다.
print(normed['red'] - normed['white'],'\n')


#  h. 모든 변수 쌍 사이의 상관계수를 출력한다.
print(wines.corr())
