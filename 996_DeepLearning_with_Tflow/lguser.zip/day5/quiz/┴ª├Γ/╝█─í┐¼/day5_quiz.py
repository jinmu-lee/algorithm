import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

wine_list = pd.read_csv('winequality-both.csv')
print('\n', wine_list.info(), '\n')

#요약 통계
print('\n', wine_list.describe(), '\n')

#요소의 유일 값
print('\n', wine_list.type.unique(), '\n')

# 요소의 빈도
print('\n', wine_list.type.value_counts(), '\n')

#종류에 따른 품질 통계
print('\n', wine_list['quality'].describe(), '\n')

#종류별 품질분포
bins = np.array([1,2,4,6,8,10])
labels = pd.cut(wine_list.quality, bins)
grouped = wine_list.groupby(['type', labels])
print('\n',grouped.size().unstack(0),'\n')

#막대 그래프 출력, 비율.
quality_sums = grouped.quality.sum().unstack(0)
normed_sums = quality_sums.div(quality_sums.sum(axis=1), axis=0)
print('\n',normed_sums,'\n')
normed_sums.plot(kind='barh', stacked=False)
plt.show()

#품질의 차이
red_list = wine_list[wine_list.type.isin(['red'])]
white_list = wine_list[wine_list.type.isin(['white'])]
red = red_list['quality']
white = white_list['quality']
box_plot_data = [red,white]

fig = plt.figure()
ax1 = fig.add_subplot(1,1,1)
box_labels = ['red', 'white']
ax1.boxplot(box_plot_data, notch=False, sym='.', vert=True, whis=1.5, showmeans=True, labels=box_labels)
ax1.xaxis.set_ticks_position('bottom')
ax1.yaxis.set_ticks_position('left')
ax1.set_xlabel('Type')
ax1.set_ylabel('Value')
plt.show()

#상관계수
print('\n', wine_list.corr(), '\n')