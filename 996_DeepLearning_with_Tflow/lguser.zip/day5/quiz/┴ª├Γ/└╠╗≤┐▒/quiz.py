import pandas as pd
import numpy as np
import  matplotlib.pyplot as plt

#a
wine=pd.read_csv("winequality-both.csv")
print('\n','a','\n', type(wine))

#b
#print('\n','b','\n', wine.info())
print('\n','b','\n',wine.describe())

#c
for column in wine.columns:
    print('\n','c','\n',wine[column].unique())

#d
for column in wine.columns:
    print('\n','d','\n',wine[column].value_counts())

#e
pivot_by_wine= wine.pivot_table(index='type')
print('\n','e','\n',pivot_by_wine)


#f
pivot_by_wine.plot(kind='barh')
plt.show()

#g
quality_compared = wine.groupby(['type','quality'])
print('\n','g','\n',quality_compared.mean())
print('\n','g','\n',quality_compared.size())

#h.
wine_corr= wine.corr()
print('\n','h','\n',wine_corr)