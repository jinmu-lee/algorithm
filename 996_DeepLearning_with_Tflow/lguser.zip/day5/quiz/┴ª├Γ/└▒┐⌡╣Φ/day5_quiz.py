import pandas as pd
import matplotlib.pyplot as plt
#1. 와인 품질 데이터셋을 이용한다.
# a. 데이터 셋을 DataFrame으로 읽어온다.
fec = pd.read_csv('winequality-both.csv')
df = pd.DataFrame(fec)

# b. 변수별 요약 통계를 표시한다.
print(fec.info())

# c. 각 요소의 유일 값을 찾아 출력한다.
for list in df.columns:
    print(df[list].unique())

# d. 각 요소의 빈도를 계산하여 출력한다.
for list in df.columns:
    print(df[list].value_counts())

# e. 와인 종류에 따른 기술 통계를 출력한다.
by_type = fec.pivot_table(index='type')
print(by_type)

# f.  와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다.
# (이때 범례도 같이 출력한다. )
by_type.plot(kind='barh')
plt.show()

# g. 와인 종류에 딸 품질의 차이를 검정하여 각 각을 출력한다.
grouped = df.groupby(['type','quality'])
print('\n',grouped,'\n')
print('\n',grouped.mean(),'\n')

# h. 모든 변수 쌍 사이의 상관계수를 출력한다.
print('\n',grouped.corr(),'\n')