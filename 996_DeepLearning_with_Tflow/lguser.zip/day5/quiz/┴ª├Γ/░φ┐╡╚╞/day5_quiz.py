import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

db = pd.read_csv('winequality-both.csv')
db_col = ['type', 'fixed acidity', 'volatile acidity', 'citric acid',
       'residual sugar', 'chlorides', 'free sulfur dioxide',
       'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol',
       'quality']

#a.
wine_df = pd.DataFrame(db, columns=db_col)
print(wine_df)

#b.
for i in wine_df.keys():
    print(i,':\n',wine_df[i].describe(), '\n')

#c.
for i in wine_df.keys():
    data_set = set()
    for data in wine_df[i]:
        if data not in data_set:
            data_set.add(data)
    print(i,': \n',data_set,'\n')

#d.
for i in wine_df.keys():
    print(i,': \n')
    print(wine_df[i].value_counts().sort_index(), '\n')
    '''
    if i == 'type':
        print(wine_df[i].value_counts(),'\n')
    else:
        max_v = wine_df[i].max()
        min_v = wine_df[i].min()
        cal_step = int((max_v-min_v)/5)
        bins = range(min_v, max_v, cal_step)#range(wine_df[i].min(), wine_df[i].max(), step=float(cal_step))
        print(bins)
        #print(pd.cut(wine_df[i], bins, labels=[1,2,3,4]))
    '''
#e.
print('max: \n', wine_df.groupby('type').max(),'\n')
print('min: \n', wine_df.groupby('type').min(),'\n')
print('median: \n', wine_df.groupby('type').median(),'\n')
print('mean: \n', wine_df.groupby('type').mean(),'\n')
print('var: \n', wine_df.groupby('type').var(),'\n')
print('std: \n', wine_df.groupby('type').std(),'\n')

#f
print("f\n")

#wine_q = wine_df.groupby(['quality', 'type']).count()
wine_q = wine_df.groupby('quality')['type'].count()
print(wine_q)
#wine_q = wine_df.pivot_table('type', index='quality', aggfunc='count')