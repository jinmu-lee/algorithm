# 1. 와인 품질 데이터셋을 이용한다.
#  a. 데이터 셋을 DataFrame으로 읽어온다.
import matplotlib.pyplot as plt
import pandas as pd
df = pd.read_csv("winequality-both.csv")

#  b. 변수별 요약 통계를 표시한다.
print(df.info())
print(df[df.columns].describe(), "\n")


#  c. 각 요소의 유일 값을 찾아 출력한다.
for column in df.columns.values:
    print(df[column].unique(), "\n")


# d. 각 요소의 빈도를 계산하여 출력한다.
for column in df.columns.values:
    print(f"{column} count", "\n")
    print(df[column].value_counts(), "\n")


#  e. 와인 종류에 따른 기술 통계를 출력한다.
print('type별 기술통계')
print(df.groupby('type').describe(), "\n")


#  f.  와인 종류에 따른 품질의 분포를 확인하기 위해 막대 그래프를 출력한다.
#     (이때 범례도 같이 출력한다. )
print("종류에 따른 품질의 분표")
quality_count = df.groupby(['type', 'quality']).size()
quality_count.unstack('type').plot(kind='barh')
plt.show()


#  g. 와인 종류에 따른 품질의 차이를 검정하여 각 각을 출력한다.

#  h. 모든 변수 쌍 사이의 상관계수를 출력한다.
print(df.corr())
