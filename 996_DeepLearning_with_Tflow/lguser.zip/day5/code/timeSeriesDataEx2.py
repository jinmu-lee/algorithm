# 시계열 basic

from datetime import datetime
import pandas as pd
import numpy as np
np.random.seed(12345)

dates = [datetime(2017, 1, 2),datetime(2017, 1, 5),datetime(2017, 1, 7),
         datetime(2017, 1, 8),datetime(2017, 1, 10),datetime(2017, 1, 12)]
ts = pd.Series(np.random.randn(6), index=dates)
print('\n',ts,'\n')
print('\n',type(ts),'\n')
print(ts[2],'\n')
print('\n',ts['1/10/2017'],'\n')
print('\n',ts['20170110'],'\n')

#긴 시계열에서는 년을 넘기거나 년,월만 넘겨서 데이터의 일부 구간만 선택할 수 있다.
longer_ts = pd.Series(np.random.randn(1000), index=pd.date_range('1/1/2010', periods=1000))
print('\n',longer_ts,'\n')
print('\n',longer_ts['2011'],'\n')
print('\n',longer_ts['2011-05'],'\n')
print('\n',longer_ts['1/6/2011':'1/11/2011'],'\n')

dates  = pd.date_range('1/1/2000', periods=100, freq='W-WED')
long_df = pd.DataFrame(np.random.randn(100,4),
                       index=dates,
                       columns=['Colorado', 'Texas', 'New York', 'Ohio'])
print(long_df.loc['5-2001'],'\n')

# 중복된 색인을 갖는 시계열
dates = pd.DatetimeIndex(['1/1/2011','1/2/2011','1/2/2011',
                          '1/2/2011','1/3/2011'])
dup_ts = pd.Series(np.arange(5), index=dates)
print('\n',dup_ts,'\n')
print('\n',dup_ts.index.is_unique)
print('\n',dup_ts['1/3/2011'],'\n')
print('\n',dup_ts['1/2/2011'],'\n')

grouped = dup_ts.groupby(level=0)
print('\n',grouped.mean(),'\n')
print('\n',grouped.count(),'\n')

# pandas에서는 일반적인 시계열은 불규칙적인 것으로 간주된다.
# 그래서 pandas에서는 리샘플링, 표준 시계열 빈도 모음, 빈도 추론, 그리고 고정된 빈도의 날짜 범위를 위한 도구가 있다.
# 날짜 범위 생성

index = pd.date_range('4/1/2012','6/1/2012')
print('\n',index,'\n')
print('\n',pd.date_range(start='4/1/2012', periods=20),'\n')
print('\n',pd.date_range(end='6/1/2012', periods=20),'\n')
print('\n',pd.date_range('1/1/2000','12/1/2000', freq='BM'),'\n') #BM(월 영업 마감일)
print('\n', pd.date_range('5/2/2012 12:56:31', periods=5),'\n')

#빈도와 날짜 오프셋

print('\n', pd.date_range('1/1/2018', '1/3/2018 23:59', freq='4h'),'\n')
print('\n', pd.date_range('1/1/2018', periods=10, freq='1h30min'),'\n')
rng = pd.date_range('1/1/2019', '9/1/2019', freq='WOM-2FRI') #월 별 주 차수
print('\n',list(rng),'\n')