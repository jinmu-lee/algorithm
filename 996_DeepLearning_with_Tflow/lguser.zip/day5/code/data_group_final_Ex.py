import pandas as pd
import numpy as np

#2012년 연방 선거관리 위원회 데이터베이스(미국 대통령 선거 데이터)
#데이터 정보:기부자의 이름, 직업, 고용형태, 주소, 기부금액

fec = pd.read_csv('P00000001-ALL.csv')
print('\n', fec.info(),'\n')
print('\n', fec.loc[123456],'\n')

#기부자와 선거자금에서 찾을 수 있는 패턴에 대한 통계를 추출하기 위해 이 데이터를 적당한 크기로
#쪼개서 나누는 다양한 방법을 찾을 수 있다.
#정당 가입 여부에 대한 데이터가 없으므로 추가해준다.
#unique 메서드를 이용해서 모든 정당 후보목록을 얻어온다.

unique_cands = fec.cand_nm.unique()
print('\n', unique_cands,'\n')

parties = {'Bachmann, Michelle':'Republican',
           'Cain, Herman':'Republican',
           'Gingrich, Newt':'Republican',
           'Huntsman, Jon':'Republican',
           'Johnson, Gary Earl':'Republican',
           'McCotter, Thaddeus G':'Republican',
           'Obama, Barack':'Democrat',
           'Paul, Ron':'Republican',
           'Pawlenty, Timothy':'Republican',
           'Perry, Rick':'Republican',
           "Roemer, Charles E. 'Buddy' III":'Republican',
           'Romney, Mitt':'Republican',
           'Santorum, Rick':'Republican'}

#사전 정보를 이용한 후보이름으로 정당 배열을 계산 할 수 있다.

print('\n', fec.cand_nm[123456:123461].map(parties),'\n')

#새로운 칼럼을 추가한다.

fec['party'] = fec.cand_nm.map(parties)
print('\n', fec['party'].value_counts(),'\n')

#분석을 단순화 하기 위해 기부금이 양수인 데이터만 골라낸다.

fec = fec[fec.contb_receipt_amt > 0]

#버락 오바마와 미트 롬니가 양대 후보이므로 두 후보의 기부금 정보만 추려낸다.
fec_mrbo =fec[fec.cand_nm.isin(['Obama, Barack', 'Romney, Mitt'])]
print('\n', fec_mrbo,'\n')

#직업별 기부 숫자
print('\n', fec.contbr_occupation.value_counts()[:10],'\n')

#직업유형은 같지만 이름이 다른 결과가 있으므로 하나의 직업을 다른 직업으로 매핑한다.

occ_mapping = {
    'INFORMATION REQUESTED PER BEST EFFORTS':'NOT PROVIDED',
    'INFORMATION REQUESTED':'NOT PROVIDED',
    'INFORMATION REQUESTED (BEST EFFORTS)':'NOT PROVIDED',
    'C.E.O':'CEO'
}

#매핑 정보가 없는 직업은 키를 그대로 가져온다.
f = lambda x: occ_mapping.get(x,x)
fec.contbr_occupation = fec.contbr_occupation.map(f)

#고용주
emp_mapping = {
    'INFORMATION REQUESTED PER BEST EFFORTS':'NOT PROVIDED',
    'INFORMATION REQUESTED':'NOT PROVIDED',
    'SELF':'SELF-EMPLOYED',
    'SELF EMPLOYED':'SELF-EMPLOYED'
}
f = lambda x: emp_mapping.get(x,x)
fec.contbr_employer = fec.contbr_employer.map(f)

#피벗 테이블을 사용해서 정당과 직업별로 데이터를 집계한 다음 최소한 2백만불 이상 기부한 직업군만 골라낸다.
print('pivot table')
by_occupation = fec.pivot_table('contb_receipt_amt',
                                index='contbr_occupation',
                                columns='party',
                                aggfunc='sum')
print(by_occupation,'\n')
over_2mm = by_occupation[by_occupation.sum(1) > 2000000]
print('\n', over_2mm,'\n')

import matplotlib.pyplot as plt

over_2mm.plot(kind='barh')
plt.show()



#오바마 후보와 롬니 후보별로 가장 많은 금액을 기부한 직군을 찾는다.
#이를 위해 후보 이름으로 그룹을 묶고 top메서드를 사용한다.

def get_top_amounts(group, key, n=5):
    totals = group.groupby(key)['contb_receipt_amt'].sum()
    return totals.sort_values(ascending=False)[:n]

grouped = fec_mrbo.groupby('cand_nm')
print('\n',grouped.apply(get_top_amounts, 'contbr_occupation', n=7),'\n')
#print('\n', fec_mrbo['contb_receipt_amt'],'\n')

#기부금액:cut함수를 이용해서 기부 규모별 버킷을 만들어 기부자 수를 분할한다.

bins = np.array([0,1,10,100,1000,10000,100000,1000000,10000000])
labels = pd.cut(fec_mrbo.contb_receipt_amt, bins)
print('\n', labels,'\n')

#위의 데이터를 기부자 이름과 버킷 이름으로 그룹을 묶어 기부 규모의 금액에 따라 히스토그램을 그릴 수 있다.

grouped = fec_mrbo.groupby(['cand_nm', labels])
print('\n',grouped.size(),'\n')
print('\n',grouped.size().unstack(0),'\n')
#결과를 확인해보면 오바마는 롬니보다 적은 금액의 기부를 훨씬 많이 받았다.
#기부금액을 모두 더한 후 버킷별로 정규화해서 후보별 전체 기부금액 대비 비율을 시각화 한다.

bucket_sums = grouped.contb_receipt_amt.sum().unstack(0)
print(bucket_sums,'\n')

normed_sums = bucket_sums.div( bucket_sums.sum(axis=1), axis=0)
print('\n',normed_sums,'\n')
normed_sums[:-2].plot(kind='barh', stacked=True) #기부금액 순에서 가장 높은 2개는 오바마에게만 있으니 제외
plt.show()

grouped = fec_mrbo.groupby(['cand_nm','contbr_st'])
totals = grouped.contb_receipt_amt.sum().unstack(0).fillna(0)
totals = totals[totals.sum(axis=1) > 100000]
print(totals[:10],'\n')

percent = totals.div(totals.sum(axis=1), axis=0)
print(percent[:10],'\n')