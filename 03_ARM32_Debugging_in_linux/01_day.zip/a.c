#include <stdio.h>

int main()
{
	printf("rasp\n");
	return 0;
}
