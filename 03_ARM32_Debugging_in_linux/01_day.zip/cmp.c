#if 1
#include <stdio.h>
int main()
{
	unsigned char a=3, b=4;
	unsigned char c;

	c = a-b;
	printf("%d\n", c );

	return 0;
}
#endif

