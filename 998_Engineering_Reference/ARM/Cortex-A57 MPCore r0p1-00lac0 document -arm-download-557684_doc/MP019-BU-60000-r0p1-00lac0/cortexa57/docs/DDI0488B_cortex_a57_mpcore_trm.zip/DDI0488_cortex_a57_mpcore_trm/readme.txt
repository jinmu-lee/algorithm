Readme history file 

ARM DDI0488 Cortex-A57 MPCore Processor Technical Reference Manual.

Latest entry at top of file.


*** Issue A, 04-Jun-13: Confidential for the r0p0 LAC release ***

  Document passes all Tech Comms release checks.

  Colin Jones

*** Issue B-1, 12-Sep-13: Confidential-Draft review draft for r0p1 ***
Zsuzsa Nagy


*** Issue B, 24-Sep-13: Confidential, issue for r0p1 ***
Release checks done
Zsuzsa Nagy

*** Updated Issue B, 01-Oct-13: Confidential, issue for r0p1 ***
Release checks done
Zsuzsa Nagy

*** Updated Issue B, 04-Oct-13: Confidential, issue for r0p1 ***
Release checks done
Zsuzsa Nagy
