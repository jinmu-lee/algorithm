static char a[] 
__attribute__((unused))  
= "hello";

int main()
{
	return 0;
}
