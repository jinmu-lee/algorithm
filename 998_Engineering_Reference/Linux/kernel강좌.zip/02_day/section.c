int a 
__attribute__((section(".modinfo")))
= 0x77777777;

int main()
{
	return 0;
}
