static char a[] 
__attribute__((used))
= "hello";

int main()
{
	return 0;
}
