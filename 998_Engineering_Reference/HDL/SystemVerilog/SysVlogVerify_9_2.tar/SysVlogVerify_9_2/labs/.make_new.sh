#!/bin/sh
  rm -fr INCA_libs irun.log irun.key waves.shm .simvision iccr.log cov_work
