#!/bin/sh

  path=`pwd`
  lab=`basename $path`

  rm -fr results > /dev/null 2>&1
  touch results

  execute () {
     echo "$1 >> $2 2>&1" >> results
     echo "$1 >> $2 2>&1"
     $1 >> $2 2>&1 || {
       echo "#FAIL: ${lab}: $1 >> $2 2>&1" >> results
       echo "#FAIL: ${lab}: $1 >> $2 2>&1"
       exit 1
      }
  }

  execute "rm -fr INCA_libs irun.log" "/dev/null"
  execute "irun *.v -q" "/dev/null"
  execute "grep TEST.COMPLETE irun.log" "/dev/null"
  for test in 1 2 3 4 5 ; do
    execute "rm -fr INCA_libs irun.log" "/dev/null"
    execute "irun ../solutions/*_${test}_*.sv -nowarn SAWSTP -q" "/dev/null"
    execute "grep TEST.COMPLETE irun.log" "/dev/null"
  done
# this for an 8.2-p001 bug affecting labs 8 - 11
  _RNC_OPTIONS=~optimize_partsel_vars; export _RNC_OPTIONS
  for test in 6 7 8 9 10 11 ; do
    execute "rm -fr INCA_libs irun.log" "/dev/null"
    execute "irun ../solutions/pack_pkg_${test}_*.sv ../solutions/intfc_if_${test}_*.sv ../solutions/mem_m_${test}_*.sv ../solutions/test_m_${test}_*.sv ../solutions/top_m_${test}_*.sv -nowarn SAWSTP -q" "/dev/null"
    execute "grep TEST.COMPLETE irun.log" "/dev/null"
  done

  execute "rm -fr INCA_libs irun.log" "/dev/null"
  echo "#PASS: $lab" >> results
  echo "#PASS: $lab"
  mv results ../solutions/
