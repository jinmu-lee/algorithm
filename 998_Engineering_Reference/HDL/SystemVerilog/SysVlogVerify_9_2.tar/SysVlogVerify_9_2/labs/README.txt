The model is a synchronous memory utilizing a bidirectional data bus.
The model is deliberately simply so that you can focus upon SV constructs.
The lab provides Verilog model, test, and top modules as a starting point.

Use the following command to run a simulation:
  irun <files> <switches>
Add the following switches as needed...
  -access <+/-rwc> Turn on read, write and/or connectivity access (for debug)
  -gui             Invoke the Graphical User Interface
  -q               Suppress informational messages(i.e., Quiet mode)

Day 1 Lab
=========
Part 1 -- Convert Verilog to SystemVerilog
The first lab session can be extremely short because at this point you have
not yet seen most of the valuable SystemVerilog verification constructs.
Your task for this lab session is to rewrite the Verilog modules using
SystemVerilog constructs wherever they "make sense". This can include:
- 2-state data types for anything that does not represent hardware
- explicit (rather than default) use of the "logic" data type
- timeunit and timeprecision declarations
- explicit (rather than default) declaration of "var" variables
- the "iff" event expression qualifier
- unsized literals
- block names at the block end
- "for" loop enhancements
- auto-increment operator
- immediate assertion with an action block
- time literals
- implicit port connections

Day 2 Lab
=========

You can negotiate with your instructor to do this second lab in one session
or incrementally as you learn the constructs you need for each part.

Part 2 -- Tasks and Functions
Modify the test:
Move the statements of the WRITE and READ blocks into tasks.
Declare the task arguments "ref" and work around any associated issues.
Also move the "@(negedge clk)" test synchronization statement to a task.

Part 3 -- Interfaces
Create an interface:
Move the nets, variables, subroutines that the memory and test use for
communication into the interface and guard those elements with modports.
Modify the memory and test:
Modify all reference to the communication elements to instead go through a port
of the interface type.
Modify the top:
Connect the memory and test interface ports to the correct modport.

Part 4 -- Clocking
Modify the interface:
Declare a clocking block synchronized to the negative clock edge.
Declare as inputs with default #1step skew all the interface signals
that the interface methods read and declare as outputs with posedge skew all
the interface signals that the interface methods write.
Modify the interface methods to use the clocking exclusively (they must no more
refer direct to the clock).

NOTE WELL: The clocking delays the memory output by one more cycle so you must
now wait TWO cycles before checking the memory data. The reference arguments
have meanwhile changed. You must save the input arguments locally before they
change and use the saved version to check the memory output.

Part 5 -- Processes
Modify the interface:
Modify the read task. Instead of waiting an extra cycle before checking the
memory, move the extra delay and checking statements to another task and
have the read task call the check task from within a fork-join_none block.
This permits the read task to complete and return in one cycle instead of two.
Question: Should this check task be an automatic task?

Part 6 -- Classes
Create a package:
Declare an enumerated type with WRITE and READ values, and a class with a
mode variable of that enumerated type and also address and data variables,
everything of course parameterized for address width and data width.
NOTE WELL: Early software versions 8.2 do not correctly override class
parameters. To work around this simply initialize the parameters to the
values you intend to override them with. After you get your lab working
you can then try to override the parameters.
Modify the interface:
Add a task to accept a reference to an object of the class as input and
pass the address and data contained therein to the write and read tasks.
Modify the test modport to import this new task instead of the write and
read tasks.
Modify the test:
Instead of directly calling the write and read tasks, create an object of the
class, set its properties appropriately, and pass it to the new interface task.
Simulate and verify:
When compiling the modules be sure to compile the package first.

Part 7 -- Random variables
Modify the test:
replace the Verilog $random() system task with the srandom() and randomize()
process methods. Include an inline constraint block to place only lower data
values into the lower addresses.

NOTE WELL: The read loop spawns a process to do the check. This new process
consumes the next value of its parent process' RNG to initialize its own RNG.
Think about how you can likewise "throw away" every other random value in the
write loop so that both loops continue to identically randomize the data. You
will remove this "hack" in the next part where you do class randomization.

Simulate and verify:
Verify that the solver honors the constraint.

Day 3 Lab
=========

Part 8 -- Random classes
Modify the package:
Make the class address variable "randc" and the data variable "rand".
You make the address "randc" to guarantee each address is written once.
Declare a class member constraint that places the lower data values into
the lower addresses.
Modify the test:
Use the srandom() and randomize() methods of the class.
Simulate and verify:
Verify that the solver honors the constraint.

Part 9 -- Functional coverage
Modify the package:
Declare a class member covergroup covering the mode, address, and data members. 
For address and data (separately), place lower values in one bin and higher
values in a second bin. Cross the address and data bins. Re-implement the class
constructor to also construct the covergroup object.
Modify the interface:
Trigger the covergroup sampling upon the completion of each transaction.
Simulate and verify:
Simulate as before and add the -coverage "functional" switch.
Invoke ICCR with the -gui switch, load the test coverage data, and verify that
the data values are evenly distributed between low and high values and that
only low values were written to low addresses and high values written to high
addresses.

Part 10 -- Arrays
Modify the package:
Change the address from "randc" to "rand".
Modify the test:
Declare an associative (sparse) memory "scoreboard" for address/data pairs.
In the write loop store the address/data pair upon completion of the write.
Modify the read loop to scan the associative memory and for each address that
was written verify that the memory model has the same data (send a transaction).
Delete each associative array entry as you verify it.
In a "final" block check that the array is empty.
Simulate and verify:

Part 11 -- Process Synchronization
Modify the test:
Declare a semaphore and initialize it with one key. Modify the write loop to
loop half as many times and get a key before modifying the transaction and put
the key back after the transaction completes. Duplicate the write loop and
enclose both copies within a fork-join block.
Simulate and verify:
