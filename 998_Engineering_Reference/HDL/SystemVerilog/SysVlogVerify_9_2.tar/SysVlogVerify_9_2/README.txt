This is the README file for:

SystemVerilog Language for Verification - version 9.2

For a class at a customer site:
- Before you run any Cadence software, verify your system patch level with
  "checkSysConf IUS9.2" and install any missing required patches.
- After installing the course, source the .class_setup script in this
  directory. This shell script sets the path variables to find executables
  and libraries. Modify this script as needed for your platform and shells.

The software products and versions required for this course are:

  -> 29651 : Incisive Enterprise Simulator - XL : version 09.20-p007

This database has been tested only with version 09.20-p007 on these operating
systems:
  Linux RH EE 4.0
  Solaris 10

The lab database is not tested on any other platform or tool version.

BUG REPORT: 8.2-p001 has a random generator bug involving part selects that
may effect labs 8-11. If your constraint solution utilizes part selects then
set the environment variable _RNC_OPTIONS to the value ~optimize_partsel_vars

UNIX users can test the database with the C-shell script:

  .testscript

The test script tests for the following licenses:
  Incisive Unified Simulator
