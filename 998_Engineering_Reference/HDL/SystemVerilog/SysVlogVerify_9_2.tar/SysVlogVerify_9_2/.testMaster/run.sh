#!/bin/sh
  irun -f run.f >> /dev/null 2>&1
