#!/bin/sh

  rm -fr results > /dev/null 2>&1
  touch results
  fail=0

  for lab in lab* ; do
    if cd $lab ; then  
      if ../sources/$lab/.make_do.sh >> /dev/null 2>&1 ; then
        echo "PASS: $lab" >> ../results
        echo "PASS: $lab"
      else
        echo "FAIL: $lab" >> ../results
        echo "FAIL: $lab"
        fail=1
      fi
      cd ..
    else  
      echo "FAIL: Can't cd $lab" >> results
      echo "FAIL: Can't cd $lab"
      fail=1
    fi
  done

  if [ ${fail} != 0 ] ; then
    echo "LAB FAILURE" >> results
    echo "LAB FAILURE"
    exit 1
  fi

  echo "ALL LABS PASS"

