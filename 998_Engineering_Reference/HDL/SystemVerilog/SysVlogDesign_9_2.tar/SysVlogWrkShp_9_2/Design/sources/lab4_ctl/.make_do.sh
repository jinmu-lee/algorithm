#!/bin/sh

  path=`pwd`
  lab=`basename $path`

  ../sources/${lab}/.make_new.sh

  rm -fr results > /dev/null 2>&1
  touch results

  execute () {
     echo "$1 >> $2 2>&1" >> results
     echo "$1 >> $2 2>&1"
     $1 >> $2 2>&1 || {
       echo "#FAIL: ${lab}: $1 >> $2 2>&1" >> results
       echo "#FAIL: ${lab}: $1 >> $2 2>&1"
       exit 1
      }
  }

  cp ../solutions/${lab}/*.sv . > /dev/null 2>&1

  echo ""
  execute "irun *.sv -q" "/dev/null"
  execute "grep PASSED irun.log" "/dev/null"

  echo "" >> results ; echo ""
  echo "#PASS: $lab" >> results
  echo "#PASS: $lab"

  cp results irun.log ../solutions/${lab}/

  echo ""

