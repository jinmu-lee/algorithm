#include <iostream>
#include <list>
using namespace std;

int main()
{
	list<int> s = { 1,2,3,4 };

	int sz = s.size();
}