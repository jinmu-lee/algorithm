#include <list>
#include <iterator>
using namespace std;

template<typename T> class Vector
{
public:
	Vector() {}
	Vector(int sz, T value) {}
};

int main()
{
	Vector v1(10, 0);
	Vector v2;
}

